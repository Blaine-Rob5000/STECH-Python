"""
Student:  Robin G. Blaine
Date:     October 18, 2017
Class:   _Python Programming

Assignment (Module 1, Chapter 3, Project 7)

Pseudocode:
Input startingSalary
Input percentageIncrease
Input numberOfYears
currentSalary = startingSalary
For year = 1 to numberOfYears+1
  Output "Year number: ", year, "    Salary: $", currentSalary
  currentSalary *= (1 + percentageIncrease/100)
"""

startingSalary = float(input("Enter starting salary: $"))
currentSalary = int(startingSalary * 100)
percentageIncrease = float(input("Enter the percentage of annual salary increase: %"))
numberOfYears = int(input("Enter the number of years: "))
print("")
for year in range (1, numberOfYears + 1):
    print("Year number: %4s" % year,
          "    Salary: $%8.2f" % (currentSalary / 100))
    currentSalary = int(currentSalary * (1 + percentageIncrease/100) + .5)
