"""
Student:  Robin G. Blaine
Date:     October 18, 2017
Class:   _Python Programming

Assignment (Module 1, Chapter 3, Project 10)

Pseudocode:
Input purchasePrice
month = 1
downPayment = purchasePrice * .10
currentBalance = purchasePrice - downPayment
monthlyPayment = currentBalance * .05
annualInterestRate = .12
monthlyInterestRate = annualInterestRate / 12
Output ("Down Payment: $", downPayment)
While (currentBalance > 0):
  monthlyInterest = currentBalance * monthlyInterestRate
  If (currentBalance < monthlyPayment + monthlyInterest):
    monthlyPayment = currentBalance + monthlyInterest
  monthlyPrincipal = monthlyPayment - monthlyInterest
  newBalance = currentBalance + monthlyInterest - monthlyPayment
  Output ("Month: ",              month,
          "Balance: $",           currentBalance,
          "Monthly Interest: $",  monthlyInterest,
          "Monthly Payment: $",   monthlyPayment,
          "Remaining Balance: $", newBalance)
  currentBalance = newBalance
  month = month + 1
"""

purchasePrice = float(input("Enter the purchase price: $"))
print("")
month = 1
downPayment = int(purchasePrice * .10 * 100 + .5) / 100
currentBalance = purchasePrice - downPayment
monthlyPayment = int(currentBalance * .05 * 100 + .5) / 100
annualInterestRate = .12
monthlyInterestRate = annualInterestRate / 12
print("Down Payment: $%-8.2f" % downPayment)
print("")
while currentBalance > 0:
    monthlyInterest = int(currentBalance * monthlyInterestRate * 100 + .5) / 100
    if currentBalance < monthlyPayment + monthlyInterest:
        monthlyPayment = currentBalance + monthlyInterest
    monthlyPrinciple = monthlyPayment - monthlyInterest
    newBalance = currentBalance + monthlyInterest - monthlyPayment
    print("Month: %4s" % month,
          "Balance: $%-10.2f" % currentBalance,
          "Monthly Interest: $%-9.2f" % monthlyInterest,
          "Monthly Payment: $%-9.2f" % monthlyPayment,
          "Remaining Balance: $%-10.2f" % newBalance)
    currentBalance = newBalance
    month += 1
