"""
Student:  Robin G. Blaine
Date:     October 18, 2017
Class:   _Python Programming

Assignment (Module 1, Chapter 3, Project 11): Lucky Sevens

Pseudocode:
Input startingPot ("Enter the amount in the pot: $")
rollNumber = 1
currentPot = startingPot
maxPot = startingPot
While currentPot > 0:
  roll = random(1 to 6) + random(1 to 6)
  if roll = 7:
    currentPot += 4
    if currentPot > maxPot:
      maxPot = currentPot
  else:
    currentPot -= 1
  rollNumber += 1
Output ("Number of rolls to break the pot: ", rollNumber)
Output ("Maximum pot: $", maxPot)
"""

import random
startingPot = int(input("Enter the amount in the pot: $"))
print("")
rollNumber = 1
currentPot = startingPot
maxPot = startingPot
while currentPot > 0:
    roll = random.randint(1, 6) + random.randint(1, 6)
    if roll == 7:
        currentPot += 4
        if currentPot > maxPot:
            maxPot = currentPot
    else:
        currentPot -= 1
#    print("Roll #%-4s" % rollNumber,
#          "You rolled: %-4s" % roll,
#          "Current Pot: $%-8s" % currentPot,
#          "Maximum Pot: $%-8s" % maxPot)
    rollNumber += 1
# print("")
# print("Starting pot: $%-8s" % startingPot)
print("Number of rolls to break the pot: %-4s" % rollNumber)
print("Maximum pot: $%-8s" % maxPot)

