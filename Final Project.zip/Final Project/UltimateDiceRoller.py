"""
Class:  	_Python Programming (ITEC 3001)
Assignment:	Final Project


GUI program to perform all sorts of dice rolls using dice of any size and exotic mechanics.

Written by: Robin G. Blaine on December ??, 2017


Notes:
http://python-gtk-3-tutorial.readthedocs.io/en/latest/Combobox.html
https://stackoverflow.com/questions/17757451/simple-ttk-combobox-demo
https://www.packtpub.com/mapt/book/application_development/9781785283758/1/ch01lvl1sec15/combo-box-widgets
http://infohost.nmt.edu/tcc/help/pubs/tkinter/web/ttk-Combobox.html
http://www.tkdocs.com/tutorial/widgets.html
 - can be used for checkbuttons and entry fields as well!
"""

import random
from tkinter import *


class UltimateDiceRoller(Frame):
    """GUI dice roller main class."""
    def __init__(self):
        """Sets up the variables, window, and widgets."""
        Frame.__init__(self)
        self.master.title("Ultimate Dice Roller")
        self.grid(padx = 5, ipadx = 5, pady = 5, ipady = 5)
        
        # Initialize list variables for each row
        # Add to/Subtract from total (1 = add / -1 = subtract / 0 = does not factor into total)
        self._addSubtract = []
        
        # Number of Dice (non-negative integer)
        self._numberOfDice = []
        
        # Number of Sides (positive integer)
        self._numberOfSides = []
        
        # Explosion/Implosion
        self._explosionDepth = [] #  non-negative integer / 0 = none 
        self._explodeInfiniteChkVal = []
        self._explodeCombinedChkVal = []
                
        self._implosionDepth = [] #  non-negative integer / 0 = none
        self._implodeInfiniteChkVal = []
        self._implodeCombinedChkVal = []

        # Advantage and Disadvantage degrees (+ = adv / - = dis / 0 = none)
        self._advantageDegree = []
        
        # Dice-Pool/Success
        self._dicePoolChkVal = []
        self._successThreshold = [] # integer, default = average die roll
        self._succeedOverUnder = [] # + = over / - = under
        
        # Constant roll modifier
        self._modifier = [] # integer, adds to / subtracts from final roll
        
        # Custom content
        self._customOutputChkVal = []
        self._customOutputMinMax = [] # lowest and highest values for roll
        self._customOutputString = [] # each item is a list of strings
        
        # Individual Row Output
        self._rowOutput = []
        
        # Set up variables for each row (0 to 9)
        for row in range(10):
            # Add to/Subtract from total (1 = add / -1 = subtract / 0 = does not factor into total)
            self._addSubtract.append(1) # default is to add to overall total
        
            # Number of Dice (non-negative integer)
            self._numberOfDice.append(0)
            
            # Number of Sides (positive integer)
            self._numberOfSides.append(6) # d6 is default
            
            # Explosion/Implosion
            self._explosionDepth.append(0) #  non-negative integer / 0 = none 
            self._explodeInfiniteChkVal.append(BooleanVar())
            self._explodeCombinedChkVal.append(BooleanVar())
            
            self._implosionDepth.append(0) #  non-negative integer / 0 = none
            self._implodeInfiniteChkVal.append(BooleanVar())
            self._implodeCombinedChkVal.append(BooleanVar())
            
            # Advantage and Disadvantage degrees (+ = adv / - = dis / 0 = none)
            self._advantageDegree.append(0)
            
            # Dice-Pool/Success
            self._dicePoolChkVal.append(BooleanVar())
            self._successThreshold.append(0) # integer, default = average die roll
            self._succeedOverUnder.append("+") # + = over / - = under
            
            # Constant roll modifier
            self._modifier.append(0) # integer, adds to/subtracts from final roll
            
            # Custom content
            self._customOutputChkVal.append(BooleanVar())
            self._customOutputMinMax.append([0, 0]) # lowest and highest values for roll
            self._customOutputString.append([]) # each item is a list of strings
            
            # Individual Row Output
            self._rowOutput.append("") # displays as a string
            
        # Combobox MAIN MENU (save, load, reset, show options)
        self._mainMenuSelection = StringVar()
        self._mainMenuChoices = ["MAIN MENU",
                                 "Save Configuration",
                                 "Load Configuration",
                                 "Reset All Fields",
                                 "Show Explosion",
                                 "Show Implosion",
                                 "Show Advantage",
                                 "Show Dice Pool",
                                 "Show Modifier",
                                 "Show Custom Output"]
        self._mainMenuSelection.set("MAIN MENU")
        
        self._showExplosionChkVal = BooleanVar()
        self._showImplosionChkVal = BooleanVar()
        self._showAdvDisChkVal = BooleanVar()
        self._showPriorityChkVal = BooleanVar()
        self._showDicePoolChkVal = BooleanVar()
        self._showModifierChkVal = BooleanVar()
        self._showCustomOutputChkVal = BooleanVar()
        
        self._mainMenu = OptionMenu(self, self._mainMenuSelection, *self._mainMenuChoices)
        self._mainMenu.grid(row = 0, column = 0, columnspan = 4)
                        
        # Labels
        self._addSubtractLabel = Label(self, text = "+/-")
        self._addSubtractLabel.grid(row = 1, column = 0)
        
        self._numberOfDiceLabel = Label(self, text = "# Dice")
        self._numberOfDiceLabel.grid(row = 1, column = 1)
        
        self._numberOfSidesLabel = Label(self, text = "# Sides")
        self._numberOfSidesLabel.grid(row = 1, column = 3)
        
        self._explosionDepthLabel = Label(self, text = "Explosion Depth")
        self._explosionDepthLabel.grid(row = 1, column = 5)
        
        self._explodeInfiniteLabel = Label(self, text = "Infinite")
        self._explodeInfiniteLabel.grid(row = 1, column = 6)
        
        self._explodeCombinedLabel = Label(self, text = "Combined")
        self._explodeCombinedLabel.grid(row = 1, column = 7)
        
        self._implosionDepthLabel = Label(self, text = "Implosion Depth")
        self._implosionDepthLabel.grid(row = 1, column = 9)
        
        self._implodeInfiniteLabel = Label(self, text = "Infinite")
        self._implodeInfiniteLabel.grid(row = 1, column = 10)
        
        self._implodeCombinedLabel = Label(self, text = "Combined")
        self._implodeCombinedLabel.grid(row = 1, column = 11)
        
        self._advantageDegreeLabel = Label(self, text = "Advantage")
        self._advantageDegreeLabel.grid(row = 1, column = 13)
        
        self._dicePoolLabel = Label(self, text = "Dice Pool")
        self._dicePoolLabel.grid(row = 1, column = 15)
        
        self._successThresholdLabel = Label(self, text = "Threshold")
        self._successThresholdLabel.grid(row = 1, column = 16)
        
        self._succeedOverUnderLabel = Label(self, text = "Over/Under")
        self._succeedOverUnderLabel.grid(row = 1, column = 17)
        
        self._modifierLabel = Label(self, text = "Modifier")
        self._modifierLabel.grid(row = 1, column = 19)
        
        self._customOutputLabel = Label(self, text = "Custom Output")
        self._customOutputLabel.grid(row = 1, column = 21)
        
        self._customOutputEditLabel = Label(self, text = "Edit")
        self._customOutputEditLabel.grid(row = 1, column = 22)
        
        self._rowResultLabel = Label(self, text = "Individual Results")
        self._rowResultLabel.grid(row = 1, column = 24)
        
        self._rowRollLabel = Label(self, text = "Roll")
        self._rowRollLabel.grid(row = 1, column = 25)
        
        # Initialize widget lists
        self._addSubtractButton = [] # toggles between + / - / <blank>
        self._numberOfDiceEntry = [] # non-negative integer
        self._numberOfSidesEntry = [] # positive integer
        
        self._explosionDepthEntry = [] # non-negative integer
        self._explodeInfiniteCheckbutton = []
        self._explodeCombinedCheckbutton = []
        
        self._implosionDepthEntry = [] # non-negative integer
        self._implodeInfiniteCheckbutton = []
        self._implodeCombinedCheckbutton = []
        
        self._advantageDegreeEntry = [] # integer (+ = adv / - = dis / 0 = neither)
        
        self._dicePoolCheckbutton = []
        self._successThresholdEntry = []
        self._succeedOverUnderButton = []
        
        self._modifierEntry = [] # integer, adds to/subtracts from final roll
        
        self._customOutputCheckbutton = []
        self._customOutputEditCombobox = [] 
        
        self._rowOutputLabel = [] # non-editable label that shows results as a string
        
        self._rowRollButton = [] # rolls just that row
        
        # set up each row of widgets
        for row in range(10):
            self._addSubtractButton.append(Button())
            
            
            self._numberOfDiceEntry.append(Entry())
            
            
            
            self._numberOfSidesEntry.append(Entry())

            
            
            self._explosionDepthEntry.append(Entry())


            
            self._explodeInfiniteCheckbutton.append(Checkbutton())


            
            self._explodeCombinedCheckbutton.append(Checkbutton())

            
            
            self._implosionDepthEntry.append(Entry())


            
            self._implodeInfiniteCheckbutton.append(Checkbutton())


            
            self._implodeCombinedCheckbutton.append(Checkbutton())

            
        
            self._advantageDegreeEntry.append(Entry())

            
            
            self._dicePoolCheckbutton.append(Checkbutton())


            
            self._successThresholdEntry.append(Entry())


            
            self._succeedOverUnderButton.append(Button())

            
            
            self._modifierEntry.append(Entry())

            
            
            self._customOutputCheckbutton.append(Checkbutton())


            
            self._customOutputEditCombobox.append(Combobox())

            
            
            self._rowOutputLabel.append(Label())

            
            
            self._rowRollButton.append(Button())
                

def main():
            """Gets the dice rolling."""
            UltimateDiceRoller().mainloop()

main()
