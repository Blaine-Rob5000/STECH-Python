"""
Class:  	_Python Programming (ITEC 3001)
Assignment:	Final Project


GUI program to perform all sorts of dice rolls using dice of any size and exotic mechanics.

Written by: Robin G. Blaine on December ??, 2017
"""

import random
from tkinter import *


class UltimateDiceRoller(Frame):
	"""GUI dice roller main class."""
	def __init__(self):
		"""Sets up the variables, window, and widgets."""
		Frame.__init__(self)
		self.master.title("Ultimate Dice Roller")
		self.grid(padx = 5, ipadx = 5, pady = 5, ipady = 5)
		
		# Initialize list variables for each row
		# Add to/Subtract from total (1 = add, -1 = subtract, 0 = do not factor into total)
		self._addSubtract = []
		
		# Number of Dice (non-negative integer)
		self._numberOfDice = []
		
		# Number of Sides (positive integer)
		self._numberOfSides = []
		
		# Explosion/Implosion
		self._explosionDepth = []
		self._explodeInfinite = []
		self._explodeInfiniteChkVal = []
		self._explodeCombined = []
		self._explodeCombinedChkVal = []
		self._showExplosionOptions = []
		self._showExplosionOptionsChkVal = []
		
		self._implosionDepth = []
		self._implodeInfinite = []
		self._implodeInfiniteChkVal = []
		self._implodeCombined = []
		self._implodeCombinedChkVal = []
		self._showImplosionOptions = []
		self._showImplosionOptionsChkVal = []

		# Advantage and Disadvantage degrees
		self._advantageDegree = []
		self._disadvantageDegree = []
		self._showAdvDis = []
		self._showAdvDisChkVal = []
		
		# Priortize Advantage/Disadvantage over Explosions/Implosions?
		self._explodePriority = []
		self._showPriority = []
		self._showPriorityChkVal = []
		
		# Dice-Pool/Success
		self._dicePool = []
		self._successThreshold = []
		self._succeedOverUnder = []
		self._showDicePool = []
		self._showDicePoolChkVal = []
		
		# Constant roll modifier
		self._modifier = []
		self._showModifier = []
		self._showModifierChkVal = []
		
		# Custom content
		self._customOutput = []
		self._customOutputChkVal = []
		self._customOutputOptions = []
		self._customOutputString = []
		
		# Individual Row Output
		self._rowOutput = []
		
		# Set up variables for each row (0 to 9)
		for row in range(10):
			# Add to/Subtract from total (1 to add, -1 to subtract)
			self._addSubtract.append(1)
			
			# Number of Dice (non-negative integer)
			self._numberOfDice.append(0)
			
			# Number of Sides (positive integer)
			self._numberOfSides.append(6)
			
			# Explosion/Implosion
			self._explosionDepth.append(0)
			self._explodeInfinite.append(False)
			self._explodeInfiniteChkVal.append(BooleanVar())
			self._explodeCombined.append(False)
			self._explodeCombinedChkVal.append(BooleanVar())
			self._showExplosionOptions.append(True)
			self._showExplosionOptionsChkVal.append(BooleanVar())
			
			self._implosionDepth.append(0)
			self._implodeInfinite.append(False)
			self._implodeInfiniteChkVal.append(BooleanVar())
			self._implodeCombined.append(False)
			self._implodeCombinedChkVal.append(BooleanVar())
			self._showImplosionOptions.append(True)
			self._showImplosionOptionsChkVal.append(BooleanVar())

			# Advantage and Disadvantage degrees
			self._advantageDegree.append(0)
			self._disadvantageDegree.append(0)
			self._showAdvDis.append(True)
			self._showAdvDisChkVal.append(BooleanVar())
			
			# Priortize Advantage/Disadvantage over Explosions/Implosions?
			self._explodePriority.append(True)
			self._showPriority.append(True)
			self._showPriorityChkVal.append(BooleanVar())
			
			# Dice-Pool/Success
			self._dicePool.append(False)
			self._successThreshold.append(0)
			self._succeedOverUnder.append(True)
			self._showDicePool.append(True)
			self._showDicePoolChkVal.append(BooleanVar())
			
			# Constant roll modifier
			self._modifier.append(0)
			self._showModifier.append(True)
			self._showModifierChkVal.append(BooleanVar())
			
			# Custom content
			self._customOutput.append(False)
			self._customOutputChkVal.append(BooleanVar())
			self._customOutputOptions.append(0)
			self._customOutputString.append([])
			
			# Individual Row Output
			self._rowOutput.append("")
		
		# Drop-Down Main Menu button
		self._mainMenuSelection = StringVar()
		self._mainMenuChoices = ["Main Menu", "Save Configuration", "Load Configuration", "Reset All Fields", "Hide/Unhide Explosions", "Hide/Unhide Implosions", "Hide/Unhide Advantage/Disadvantage", "Hide/Unhide Priority", "Hide/Unhide Dice Pool", "Hide/Unhide Modifier", "Hide/Unhide Custom Output"]
		self._mainMenuSelection.set("Main Menu")
		self._mainMenu = OptionMenu(self, self._mainMenuSelection, *self._mainMenuChoices)
		self._mainMenu.grid(row = 0, column = 0, columnspan = 4)
				
		# Labels
		self._addSubtractLabel = Label(self, text = "Add/Subtract")
		self._addSubtractLabel.grid(row = 1, column = 0)
		
		self._numberOfDiceLabel = Label(self, text = "# Dice")
		self._numberOfDiceLabel.grid(row = 1, column = 1)
		
		self._numberOfSidesLabel = Label(self, text = "# Sides")
		self._numberOfSidesLabel.grid(row = 1, column = 3)
		
		self._explosionDepthLabel = Label(self, text = "Explosion Depth")
		self._explosionDepthLabel.grid(row = 1, column = 5)
		
		self._explodeInfiniteLabel = Label(self, text = "Infinite")
		self._explodeInfiniteLabel.grid(row = 1, column = 6)
		
		self._explodeCombinedLabel = Label(self, text = "Combined")
		self._explodeCombinedLabel.grid(row = 1, column = 7)
		
		self._implosionDepthLabel = Label(self, text = "Implosion Depth")
		self._implosionDepthLabel.grid(row = 1, column = 9)
		
		self._implodeInfiniteLabel = Label(self, text = "Infinite")
		self._implodeInfiniteLabel.grid(row = 1, column = 10)
		
		self._implodeCombinedLabel = Label(self, text = "Combined")
		self._implodeCombinedLabel.grid(row = 1, column = 11)
		
		self._advantageDegreeLabel = Label(self, text = "Advantage")
		self._advantageDegreeLabel.grid(row = 1, column = 13)
		
		self._disadvantageDegreeLabel = Label(self, text = "Disadvantage")
		self._disadvantageDegreeLabel.grid(row = 1, column = 14)
		
		self._explodePriorityLabel = Label(self, text = "Priority")
		self._explodePriorityLabel.grid(row = 1, column = 16)
		
		self._dicePoolLabel = Label(self, text = "Dice Pool")
		self._dicePoolLabel.grid(row = 1, column = 18)
		
		self._successThresholdLabel = Label(self, text = "Threshold")
		self._successThresholdLabel.grid(row = 1, column = 19)
		
		self._succeedOverUnderLabel = Label(self, text = "Over/Under")
		self._succeedOverUnderLabel.grid(row = 1, column = 20)
		
		self._modifierLabel = Label(self, text = "Modifier")
		self._modifierLabel.grid(row = 1, column = 22)
		
		self._customOutputLabel = Label(self, text = "Custom Output")
		self._customOutputLabel.grid(row = 1, column = 24)
		
		self._customOutputEditLabel = Label(self, text = "Edit")
		self._customOutputEditLabel.grid(row = 1, column = 25)
		
		self._rowResultLabel = Label(self, text = "Individual Results")
		self._rowResultLabel.grid(row = 1, column = 27)
		
		self._rowRollLabel = Label(self, text = "Roll")
		self._rowRollLabel.grid(row = 1, column = 28)
		
		# Initialize widget lists
		self._addSubtractButton = []
		self._numberOfDiceField = []
		self._numberOfSidesField = []
		
		self._explosionDepthField = []
		self._explodeInfiniteCheckBox = []
		self._explodeCombinedCheckbox = []
		
		self._implosionDepthField = []
		self._implodeInfiniteCheckbox = []
		self._implodeCombinedCheckbox = []
		
		self._advantageDegreeField = []
		self._disadvantageDegreeField = []
		
		self._explodePriorityButton = []
		
		self._dicePoolCheckbox = []
		self._successThresholdField = []
		self._succeedOverUnderButton = []
		
		self._modifierField = []
		
		self._customOutputCheckbox = []
		self._customOutputEditButton = []
		
		self._rowOutputField = []
		
		self._rowRollButton = []
		
		# set up each row of widgets
		for row in range(10):
			self._addSubtractButton.append(Button())
			
			
			self._numberOfDiceField.append(Field())
			
			
			self._numberOfSidesField.append(Field())
			
			
			self._explosionDepthField.append(Field())
			
			
			self._explodeInfiniteCheckBox.append(Checkbutton())
			
			
			self._explodeCombinedCheckbox.append(Checkbutton())
			
			
			self._implosionDepthField.append(Field())
			
			
			self._implodeInfiniteCheckbox.append(Checkbutton())
			
			
			self._implodeCombinedCheckbox.append(Checkbutton())
			
			
			
			self._advantageDegreeField.append(Field())
			
			
			self._disadvantageDegreeField.append(Field())
			
			
			self._explodePriorityButton.append(Button())
			
			
			self._dicePoolCheckbox.append(Checkbutton())
			
			
			self._successThresholdField.append(Field())
			
			
			self._succeedOverUnderButton.append(Checkbutton())
			
			
			self._modifierField.append(Field())
			
			
			self._customOutputCheckbox.append(Checkbutton())
			
			
			self._customOutputEditButton.append(Button())
			
			
			self._rowOutputField.append(Field())
			
			
			self._rowRollButton.append(Button())
			

def main():
		"""Gets the dice rolling."""
		UltimateDiceRoller().mainloop()

main()