"""
Student:  Robin G. Blaine
Date:     November 28, 2017
Class:   _Python Programming

Assignment (Module 5, Data Structures - Chapter 3, Project 1):
	A sequential search of a sorted list can halt when the target is less than a given
	element in the list. Define a modified version of this algorithm and state the
	computational complexity, using big-O notation, of its best-, worst-, and average-
	case performances.
"""


def sortedSequentialSearch(target, sortedList):
	"""Returns the position of the target item in the sorted list if found, or -1 otherwise."""
	position = 0
	while position < len(sortedList) and target >= sortedList[position]:
		if target == sortedList[position]:
			return position
		position += 1
	return -1


"""
Analysis:

Best-case scenario:
	The target is either the first item in the list or is less than the first item in the
	list (indicating that the item is not present on the list as it is a pre-sorted list).

	Computational Complexity:  O(1)


Worst-case scenario:
	The target is at the end of the list or not on the list at all.

	Computational Complexity:  O(n)


Average-case scenario:
	(n + n - 1 + n - 2 + n - 3 ... + 1) / n = (n + 1) / 2
	For very large values of n, the constant factor of 2 is insignificant.
	
	Computational Complexity:  O(n)
"""
	