"""
Student:  Robin G. Blaine
Date:     November 28, 2017
Class:   _Python Programming

Assignment (Module 5, Data Structures - Chapter 3, Project 5):
	Python's 'list' method 'sort' includes the keyword argument 'reverse,' whose default
	value is 'False.'  The programmer can override this value to sort a list in descending
	order. Modify the 'selectionSort' function discussed in this chapter so that it allows
	the programmer to supply this additional argument to redirect the sort.
"""


def selectionSort(lyst, reverse = False):
	"""Sorts the list in ascending order if reverse is False, or descending order otherwise."""
	i = 0
	while i < len(lyst) - 1:
		minIndex = i
		j = i + 1
		while j < len(lyst):
			if lyst[j] < lyst[minIndex] and not reverse:
				minIndex = j
			elif lyst[j] > lyst[minIndex] and reverse:
				minIndex = j
			j += 1
		if minIndex != i:
			swap(lyst, minIndex, i)
		i += 1


def swap(lyst, i, j):
	"""Swaps the items in the list at the two indices, i and j."""
	temp = lyst[i]
	lyst[i] = lyst[j]
	lyst[j] = temp


def main():
	myList1 = [5, 3, 1, 4, 6, 9, 0, 2, 8, 7]
	print("\n      Unsorted list:", myList1)
	selectionSort(myList1)
	print("\n        Sorted list:", myList1)
	selectionSort(myList1, reverse = True)
	print("\nReverse sorted list:", myList1)
	print("\n")
	myList2 = ["Edgar", "Allen", "Bob", "Doug", "Chuck"]
	print("\n      Unsorted list:", myList2)
	selectionSort(myList2)
	print("\n        Sorted list:", myList2)
	selectionSort(myList2, reverse = True)
	print("\nReverse sorted list:", myList2)
	print("\n")

main()

