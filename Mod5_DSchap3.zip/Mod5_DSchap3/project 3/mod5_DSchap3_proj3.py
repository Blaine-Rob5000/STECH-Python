"""
Student:  Robin G. Blaine
Date:     November 28, 2017
Class:   _Python Programming

Assignment (Module 5, Data Structures - Chapter 3, Project 3):
	Python's pow function returns the result of raising a number to a given power.
	Define a function expo that performs this task and state its computational
	complexity using Big-O notation. The first argument of this function is the
	number and the second argument is the exponent (nonnegative numbers only).
	You can use either a loop or a recursive function in your implementation.
	
	From Rocky:  just use whole numbers for the exponent
"""


def expo(base, exponent):
	"""Returns the value of the base raised to the power of the exponent."""
	if exponent < 0:
		print("Error!  Exponent must be a nonnegative integer!")
		return
	result = 1.0
	count = 0
	while count < exponent:
		result *= base
		count += 1
	return result

def main():
	"""Takes input and outputs results."""
	while True:
		baseString = input("\nEnter the base value (Q to quit): ")
		if baseString[0].upper() == "Q":
			break
		else:
			base = float(baseString)
		exponentString = input("Enter the exponent (whole numbers only; Q to quit): ")
		if exponentString[0].upper() == "Q":
			break
		else:
			exponent = int(exponentString)
		print("\n" + str(base) + " ^ " + str(exponent) + " = " + "%.2f" % expo(base, exponent) + "\n")

main()

"""
Analysis:

Best-case scenario:
	The exponent is 0, 1, or invalid.

	Computational Complexity:  O(1)


Worst-case/Average-case scenarios:
	These are identical.  The loop repeats n times, where n is the exponent.

	Computational Complexity:  O(n)
"""
