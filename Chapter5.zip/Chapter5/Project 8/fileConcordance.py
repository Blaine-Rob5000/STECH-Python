"""
Student:  Robin G. Blaine
Date:     October 20, 2017
Class:   _Python Programming

Assignment (Module 2, Chapter 5, Project 7): fileConcordance
write a program that displays a concordance for a file

Pseudocode:
Define getWords(filename):
    Open file(filename)
    For line In file:
        data += line
    tempList = data.split()
    Return tempList

Define removeDuplicates(myList):
    tempList = []
    For word In myList:
        If word Not In templist:
           Append word to tempList
    return tempList

Define maine():
    wordList = []
    uniqueList = []
    Input filename
    wordList = getWords(filename)
    uniqueList = removeDuplicates(wordList)
    Sort uniqueList
    Print uniqueList

main()
"""

def getWords(filename):
    """Gets words from the file and returns them as a list."""
    data = ""
    file = open(filename, 'r')
    for line in file:
        data += line
    tempList = data.split()
    return tempList

def removeDuplicates(myList):
    """Removes duplicate words and returns the updated list."""
    tempList = []
    for word in myList:
        if word not in tempList:
            tempList.append(word.lower())
    return tempList

def createConcordance(fullList, uniqueList):
    """Creates a concordance from the full list and the unique list."""
    concordance = {}
    for word in uniqueList:
        concordance[word] = 0
    for word in fullList:
        concordance[word.lower()] += 1
    return concordance

def printSorted(concordance, keyList):
    """Prints out the concordance in the order of the submitted keyList."""
    for word in keyList:
        print("%10s" % word, ":", concordance[word])

def main():
    wordList = []
    uniqueList = []
    fileConcordance = {}
    filename = input("Enter the filename (or ENTER for default file): ")
    if filename == "":
        filename = "project7.txt"
    print("")
    wordList = getWords(filename)
    print("Initial list: ", wordList)
    print("")
    uniqueList = removeDuplicates(wordList)
    print("Unique list: ", uniqueList)
    print("")
    uniqueList.sort()
    print("Sorted unique list: ", uniqueList)
    print("")
    fileConcordance = createConcordance(wordList, uniqueList)
    print("Concordance: ", fileConcordance)
    print("")
    printSorted(fileConcordance, uniqueList)

main()
