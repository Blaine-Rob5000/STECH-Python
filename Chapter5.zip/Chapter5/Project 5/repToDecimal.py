"""
Student:  Robin G. Blaine
Date:     October 19, 2017
Class:   _Python Programming

Assignment (Module 2, Chapter 5, Project 5): repToDecimal
create a function that accepts a string ('number') and an integer ('base')
'number' is assumed to be a number of base 'base'
converts 'number' to a decimal number 'decimal' and returns that value
uses a lookup table that includes the 0:9 and A:F

Pseudocode:

"""

conversionTable = {'0' :  0, '1' :  1, '2' :  2, '3' :  3, '4' :  4,
                   '5' :  5, '6' :  6, '7' :  7, '8' :  8, '9' :  9,
                   'A' : 10, 'B' : 11, 'C' : 12, 'D' : 13, 'E' : 14,
                   'F' : 15}

def repToDecimal(number, base):
    """
    Converts string 'number' (a number of base 'base') to decimal
    number 'decimal,' and returns that value.
    """

    decimal = 0
    exponent = len(number) - 1
    for digit in number:
        if conversionTable[digit] > base - 1:
            return -1
        decimal += conversionTable[digit] * base ** exponent
        exponent -= 1
    return decimal

def main():
    """
    Allows the user to input numbers to convert to decimal.
    """

    number = ""
    base = 0
    while True:
        decimal = 0
        number = input("Enter the number to convert (Q to quit): ")
        if number.upper() == 'Q':
            break
        base = int(input("Enter the number's base: "))
        print("")
        decimal = repToDecimal(number, base)
        if decimal == -1:
            print("Invalid input! Number out of range for base", base)
        else:
            print(decimal)
        print("")

main()
