"""
Student:  Robin G. Blaine
Date:     October 19, 2017
Class:   _Python Programming

Modified from generator.py from textbook The Fundamentals of Python: First
  Programs, page 182

Assignment (Module 2, Chapter 5, Project 3):
modify the sentence-generator program from Case Study 5.3

Pseudocode:

Define Function: getWords(filename)
  Open filename for Reading
  Read data from filename
  tempList = Tuple(Split data)
  Return tempList

Define Function: sentence()
  Return nounPhrase() + verbPhrase() + "."

Define Function: nounPhrase()
  Return Random(article)

Define Function: verbPhrase()
  Return Random(verb) + " " + nounPhrase + " " + prepositionalPhrase

Define Function: prepositionalPhrase()
  Return Random(preposition) + " " + nounPhrase

Define Function: main()
  Input number
  For count In Range(number)
      Output sentence()

article = getWords(articles.txt)
noun = getWords(nouns.txt)
preposition = getWords(prepositions.txt)
verb = getWords(verbs.txt)

main()
"""

import random

def getWords(filename):
    """Gets words from the file and returns them as a tuple."""
    data = ""
    file = open(filename, 'r')
    for line in file:
        data += line
    tempList = tuple(data.split())
    return tempList

def sentence():
    """Builds and returns a sentence."""
    return nounPhrase() + " " + verbPhrase() + "."

def nounPhrase():
    """Builds and returns a noun phrase."""
    return random.choice(article) + " " + random.choice(noun)

def verbPhrase():
    """Builds and returns a verb phrase."""
    return random.choice(verb) + " " + nounPhrase() + " " + prepositionalPhrase()

def prepositionalPhrase():
    """Builds and returns a prepositional phrase."""
    return random.choice(preposition) + " " + nounPhrase()

def main():
    """Allows the user to input the number of sentences to generate."""

#    print("Articles:     ", article)
#    print("Nouns:        ", noun)
#    print("Prepositions: ", preposition)
#    print("Verbs:        ", verb)
#    print("")
    
    number = int(input("Enter the number of sentences to generate: "))
    print("")
    for count in range(number):
        print(sentence())

article     = getWords("articles.txt")      # set up article tuple
noun        = getWords("nouns.txt")         # set up noun tuple
preposition = getWords("prepositions.txt")  # set up prepositions tuple
verb        = getWords("verbs.txt")         # set up verb tuple

main()
