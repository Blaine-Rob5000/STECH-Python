"""
Student:  Robin G. Blaine
Date:     November 30, 2017
Class:   _Python Programming

Assignment (Module 5, Data Structures - Chapter 4, Project 3):
	Add the methods grow and shrink to the Array class. These methods should use
	the strategies discussed in this chapter to increase or decrease the length of the list
	contained in the array. Make sure that the physical size of the array does not
	shrink below the user-specified capacity and that the array's cells use the fill value
	when the array's size is increased.
	
	Include code that tests your modifications to the Array class.
"""

from arrays import Array

def main():
	"""Tests the modifications to the Array class."""
	a = Array(5, "item")
	print("\n        Array:", a)
	print("Physical size:", len(a))
	print(" Logical size:", a.size())
	a.grow()
	print("\n        Array:", a)
	print("Physical size:", len(a))
	print(" Logical size:", a.size())
	a.shrink()
	print("\n        Array:", a)
	print("Physical size:", len(a))
	print(" Logical size:", a.size())
	a.shrink()
	print("\n        Array:", a)
	print("Physical size:", len(a))
	print(" Logical size:", a.size())

	
main()
