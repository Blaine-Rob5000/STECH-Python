"""
File: arrays.py

An Array is like a list, but the client can use
only [], len, iter, and str.

To instantiate, use:

	<variable> = Array(<capacity>, <optional fill value>)
	
The fill value defaults to None.
"""

class Array(object):
	"""Represents an array."""
	
	def __init__(self, capacity, fillValue = None):
		"""Capacity is the static size of the array.
		fillValue is placed at each position."""
		self._minimumCapacity = capacity
		self._defaultFillValue = fillValue
		self._items = list()
		for count in range(capacity):
			self._items.append(fillValue)
		self._logicalSize = 0
		if fillValue != None:
			self._logicalSize = capacity
	
	def __len__(self):
		"""-> The capacity of the array."""
		return len(self._items)
	
	def __str__(self):
		"""-> The string representation of the array."""
		return str(self._items)
	
	def __iter__(self):
		"""Supports traversal with a for loop."""
		return iter(self._items)
	
	def __getitem__(self, index):
		"""Subscript operator for access at index."""
		return self._items[index]
	
	def __setitem__(self, index, newItem):
		"""Subscript operator for replacement at index."""
		self._items[index] = newItem
	
	def size(self):
		"""-> The logical size of the array."""
		self._logicalSize = 0
		for index in range(len(self._items)):
			if self._items[index] != None:
				self._logicalSize = index + 1
		return self._logicalSize
	
	def grow(self):
		"""Doubles the physical size of the array."""
		for count in range(len(self._items)):
			self._items.append(self._defaultFillValue)
	
	def shrink(self):
		"""Halves the physical size of the array, but not
		below the user-specified initial capacity."""
		for count in range(len(self._items) // 2):
			if len(self._items) > self._minimumCapacity:
				self._items.pop()
			
			

