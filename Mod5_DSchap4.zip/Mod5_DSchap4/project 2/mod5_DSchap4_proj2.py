"""
Student:  Robin G. Blaine
Date:     November 30, 2017
Class:   _Python Programming

Assignment (Module 5, Data Structures - Chapter 4, Project 2):
	Add preconditions to the methods __getitem__ and __setitem__ of the Array class.
	The precondition of each method is 0 <= index < size().  Be sure to raise an
	exception if the precondition is not satisfied.
	
	Include code that tests your modifications to the Array class.
	
	Note:  Because these projects have not yet called for the addition of an append
	function, items cannot be added to an empty array (one in which all values are
	None).  As such, assignments cannot be made for items in an empty array.
"""

from arrays import Array

def main():
	"""Tests the modifications to the Array class."""
	a = Array(10)
	print("\n     Array a:", a)
	print("      Length:", len(a))
	print("Logical size:", a.size())
	print("")
	for i in range(10):
		try:
			a[i] = "item " + str(i + 1)
		except IndexError:
			print("Illegal index:", i)
	b = Array(10, "item #")
	print("\n     Array b:", b)
	print("      Length:", len(b))
	print("Logical size:", b.size())
	print("")
	for i in range(10):
		b[i] = "item " + str(i + 1)
	print("\n     Array b:", b)
	print("      Length:", len(b))
	print("Logical size:", b.size())
	print("")
	try:
		b[10] = "item 11"
	except IndexError:
		print("Illegal index: 10")
	
main()
