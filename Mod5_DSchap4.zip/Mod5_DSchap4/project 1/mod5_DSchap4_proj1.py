"""
Student:  Robin G. Blaine
Date:     November 30, 2017
Class:   _Python Programming

Assignment (Module 5, Data Structures - Chapter 4, Project 1):
	Add an instance variable _logicalSize to the Array class. This variable is initially 0
	and will track the number of items currently available to users of the array.
	Then add the method size() to the Array class. This method shouuld return the
	array's logical size. The method __len__ should still return the array's capacity or
	physical size.
	
	Include code that tests your modifications to the Array class.
"""

from arrays import Array

def main():
	"""Tests the modifications to the Array class."""
	a = Array(10)
	print("\n       Array:",a)
	print("      Length:", len(a))
	print("Logical size:", a.size())
	for i in range(5):
		a[i] = "item " + str(i + 1)
	print("\n       Array:",a)
	print("      Length:", len(a))
	print("Logical size:", a.size())
	for i in range(10):
		a[i] = "item " + str(i + 1)
	print("\n       Array:",a)
	print("      Length:", len(a))
	print("Logical size:", a.size())

main()
