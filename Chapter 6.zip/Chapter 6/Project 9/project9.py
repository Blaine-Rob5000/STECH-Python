"""
Student:  Robin G. Blaine
Date:     October 24, 2017
Class:   _Python Programming

Assignment (Module 2, Chapter 6, Project 9):
    Write a program that computes and prints the average of the numbers in a
    text file.  Make use of 2 higher-order functions to simplify the design.

Pseudocode:
Function getNumbers(filename)
    read data from text file filename
    split data and add as float to tempList
    Return tempList

Function add(x, y)
    Return x + y

Main
    Input filename (or Enter for default.txt)
    numList = getNumbers from filename
    total = reduce(add, numList)
    Print total / length of numList
"""

from functools import reduce

def getNumbers(filename):
    """Get data from <filename>, convert to float, and return as a list."""
    data = ""
    file = open(filename, 'r')
    for line in file:
        data += line
    tempList = data.split()
    tempList = list(map(float, tempList))
    return tempList

def add(x, y):
    """Returns the sum of two numbers."""
    return x + y

def main():
    filename = input("Enter the file to be read (ENTER for default file): ")
    if (filename == ""):
        filename = "default.txt"

    numList = getNumbers(filename)

    precision = int(input("\nEnter the desired precision: "))
    precision = 10 ** precision

    print("\nNumbers:", numList)

    total = int(reduce(add, numList) * precision) / precision
    divisor = len(numList)
    average = int(total / divisor * precision) / precision
    print("\nAverage:", total, "/", divisor, "=", average)

main()
