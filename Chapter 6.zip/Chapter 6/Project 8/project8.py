"""
Student:  Robin G. Blaine
Date:     October 24, 2017
Class:   _Python Programming

Assignment (Module 2, Chapter 6, Project 8):
test the recursive strategy for printing the elements of a sequence

Pseudocode:
Function printAll(seq)
    Print seq[0]
    printAll(seq[1:])

Function main()
    define a test string
    printAll(test string)
    define a test list
    printAll(test list)
    Print explanation

main()
"""

def printAll(seq, margin):
    blanks = "_" * (margin)
    if seq:
        print("%4s" % str(margin // 4 + 1), ":", blanks, end = "")
        print(seq[0])
        printAll(seq[1:], margin + 4)

def main():
    testString = "0123456789ABCDEF"
    print("testString =", testString)
    print("\nCall#:")
    printAll(testString, 0)
    print("\n")
    testList = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89]
    print("testList =", testList)
    print("\nCall#:")
    printAll(testList, 0)
    print("\n")
    print("The function performs as expected. However, since it never returns\n",
        "to the function that called it, each recursion increases the demand\n",
        "on system resources by way of stack frames that are not resolved.")

main()
