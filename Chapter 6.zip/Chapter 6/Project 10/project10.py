"""
Student:  Robin G. Blaine
Date:     October 24, 2017
Class:   _Python Programming

Assignment (Module 2, Chapter 6, Project 10):


Pseudocode:


"""

def myRange():
    return myList

def main():
    newList = input("Enter a list: ")

main()
