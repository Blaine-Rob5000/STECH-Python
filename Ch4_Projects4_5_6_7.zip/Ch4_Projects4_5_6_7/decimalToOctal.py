"""
Student:  Robin G. Blaine
Date:     October 18, 2017
Class:   _Python Programming

Assignment (Module 1, Chapter 4, Project 4.2): decimal to octal

Pseudocode:
Input decimal

Output octal
"""

decimal = int(input("Enter an decimal integer: "))
print("")
octal = ""
if decimal == 0:
    print(0)
else:
    while decimal > 0:
        remainder = decimal % 8
        decimal = decimal // 8
        octal = str(remainder) + octal
    print("The octal value is: ", octal)
