"""
Student:  Robin G. Blaine
Date:     October 18, 2017
Class:   _Python Programming

Assignment (Module 1, Chapter 4, Project 5.1): bit shift left

Pseudocode:
Input bitString
leftShift = bitString[1:length of bitString] + bitString[0]
Output leftShift
"""

bitString = input("Enter a binary string:")
leftShift = bitString[1:len(bitString)] + bitString[0]
print("After left shift: ", leftShift)
