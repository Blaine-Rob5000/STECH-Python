"""
Student:  Robin G. Blaine
Date:     October 18, 2017
Class:   _Python Programming

Assignment (Module 1, Chapter 4, Project 6):
encrypt a message by converting the characters in it to their ASCII value,
then converting the ASCII value to a binary value,
then shifting the digits in that binary value one place to the left

Pseudocode:
Input message
encryption = ""
For index = 0 To length of message
  asciiDec = ASCII value of message[index]
  asciiBin = ""
  While asciiDec > 0
    remainder = asciiDec % 2
    asciiDec = asciiDec // 2
    asciiBin = String(remainder) + asciiBin
  asciBin = asciiBin[1:length of asciiBin] + asciiBin[0]
  encryption = encryption asciiBin + " "
Output encryption
"""

message = input("Enter a message to be encoded: ")
encryption = ""
for index in range(0, len(message)):
    asciiDec = ord(message[index])
    asciiBin = ""
    while asciiDec > 0:
        remainder = asciiDec % 2
        asciiDec = asciiDec // 2
        asciiBin = str(remainder) + asciiBin
    asciiBin = asciiBin[1:len(asciiBin)] + asciiBin[0]
    encryption += asciiBin + " "
print("The encoded message is: ", encryption)
