"""
Student:  Robin G. Blaine
Date:     October 18, 2017
Class:   _Python Programming

Assignment (Module 1, Chapter 4, Project 4.1): octal to decimal

Pseudocode:
Input octal
decimal = 0
exponent = len(octal) - 1
For digit In octal:
  If digit > 7 Then Output error message & Quit
  decimal += digit * 8^exponent
  exponent -= 1
Output decimal
"""

octal = input("Enter an octal number: ")
decimal = 0
exponent = len(octal) - 1
for digit in octal:
    if int(digit) > 7:
        print("Invalid octal number...")
        exit()
    decimal += int(digit) * 8 ** exponent
    exponent -= 1
print("")
print("The decimal value is: ", decimal)


