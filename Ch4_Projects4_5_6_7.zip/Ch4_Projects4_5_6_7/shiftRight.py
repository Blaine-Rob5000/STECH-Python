"""
Student:  Robin G. Blaine
Date:     October 18, 2017
Class:   _Python Programming

Assignment (Module 1, Chapter 4, Project 5.2): bit shift right

Pseudocode:
Input bitString
rightShift = bitString[last character] + bitString[0:length of bitString - 1]
Output rightShift
"""

bitString = input("Enter a binary string:")
rightShift = bitString[-1] + bitString[0:len(bitString) - 2]
print("After right shift: ", rightShift)
