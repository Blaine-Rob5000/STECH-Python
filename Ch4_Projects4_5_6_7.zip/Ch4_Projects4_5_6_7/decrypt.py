"""
Student:  Robin G. Blaine
Date:     October 18, 2017
Class:   _Python Programming

Assignment (Module 1, Chapter 4, Project 7):
write a program to decrypt a message encrypted by Project 6

Pseudocode:
Input message
decryption = ""
listOfCharacters = message.split
For binary In listOfCharacters
  binary = binary[last character] + binary[0 to next-to-last character]
  asciiCode = 0
  exponent = len(binary) - 1
  For digit In binary
    asciiCode = asciiCode + digit * 2^exponent
    exponent = exponent - 1
  descryption = descryption + character(asciiCode)
Output decryption
"""

message = input("Enter a message to be decoded: ")
decryption = ""
listOfCharacters = message.split()
for binary in listOfCharacters:
    binary = binary[-1] + binary[0:len(binary) - 1]
    asciiCode = 0
    exponent = len(binary) - 1
    for digit in binary:
        asciiCode += int(digit) * 2 ** exponent
        exponent -= 1
    decryption += chr(asciiCode)
print("The decoded message is: ", decryption)
