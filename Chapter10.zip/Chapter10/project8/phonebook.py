"""
Student:  Robin G. Blaine
Date:     November 20, 2017
Class:   _Python Programming

Assignment (Module 3, Chapter 10, Project 8):
Design, implement, and test a network application that maintains an
online phonebook. The data model for the phonebook is saved in a file
on the server's computer. Clients should be able to look up a person's
phone number or add a name and number to the phonebook. The server
should handle multiple clients without delays.
"""

class Phonebook(object):
    """Saves names and phone numbers as a dictionary and stores them in a text file.  Returns the phone number associated with a submitted name."""

    def __init__(self):
        """Initializes the phonebook."""
        self._namesAndNumbers = {}
        self._loadFile()
        
    def __str__(self):
        """Returns the names and associated numbers in the phonebook."""
        result = ""
        for name in self._namesAndNumbers:
            result += '  Name: ' + name + '\n'
            result += 'Number: ' + self._namesAndNumbers[name] + '\n'
        return result

    def _loadFile(self):
        """Loads the dictionary of names and numbers."""
        try:
            readFile = open('phonebook.txt', 'r')
            print('\nPhonebook file opened...')
            if not readFile:
                print('\nPhonebook file empty...')
            else:
                for line in readFile:
                    separator = line.index('#')
                    name = line[:separator]
                    number = line[separator + 1:]
                    self._namesAndNumbers.update({name : number})
                print('\nPhonebook file loaded...')
                print(self._namesAndNumbers)
        except:
            print('\nCreating new phonebook file...')
            writeFile = open('phonebook.txt', 'w')
            writeFile.close()
            return
          
    def _updateFile(self):
        """Updates the phonebook text file."""
        writeFile = open('phonebook.txt', 'w')
        for name in self._namesAndNumbers:
            writeFile.write(name + '#' + self._namesAndNumbers[name] + '\n')
        writeFile.close()
        print('\nPhonebook file updated...')
        print(self._namesAndNumbers)

    def addNumber(self, newEntry):
        """Adds a new name and number to the phonebook."""
        separator = newEntry.index('#')
        name = newEntry[:separator]
        number = newEntry[separator + 1:]
        if name not in self._namesAndNumbers:
            self._namesAndNumbers.update({name : number})
            self._updateFile()
            print('\nName and number added to phonebook...')
            return True
        else:
            print('\nName already exists in phonebook...')
            return False
        
    def findNumber(self, name):
        """Retrieves the phone number associated with the submitted name."""
        if name in self._namesAndNumbers:
            return self._namesAndNumbers[name]
        else:
            return name + " not found."
        