"""
Student:  Robin G. Blaine
Date:     November 20, 2017
Class:   _Python Programming

Assignment (Module 3, Chapter 10, Project 8):
Design, implement, and test a network application that maintains an
online phonebook. The data model for the phonebook is saved in a file
on the server's computer. Clients should be able to look up a person's
phone number or add a name and number to the phonebook. The server
should handle multiple clients without delays.
"""

from socket import *
from codecs import decode
from threading import Thread
from doctor import Doctor

class ClientHandler(Thread):
    """Handles a session between a doctor and a patient."""
    def __init__(self, client, dr):
        Thread.__init__(self)
        self._client = client
        self._dr = dr

    def run(self):
        self._client.send(bytes("Enter your name...", CODE))

        while True:
            message = decode(self._client.recv(BUFSIZE), CODE)
            if not message:
                print('Client disconnected')
                self._client.close()
                break
            else:
                self._client.send(bytes(self._dr.reply(message), CODE))

HOST = 'localhost'
PORT = 21567
ADDRESS = (HOST, PORT)
CODE = 'ascii'
BUFSIZE = 1024

server = socket(AF_INET, SOCK_STREAM)
server.bind(ADDRESS)
server.listen(5)

while True:
    print('Waiting for connection . . .')
    client, address = server.accept()
    print('... connected from:', address)
    dr = Doctor()
    handler = ClientHandler(client, dr)
    handler.start()
