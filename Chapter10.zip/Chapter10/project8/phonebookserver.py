"""
Student:  Robin G. Blaine
Date:     November 20, 2017
Class:   _Python Programming

Assignment (Module 3, Chapter 10, Project 8):
Design, implement, and test a network application that maintains an
online phonebook. The data model for the phonebook is saved in a file
on the server's computer. Clients should be able to look up a person's
phone number or add a name and number to the phonebook. The server
should handle multiple clients without delays.
"""

from socket import *
from codecs import decode
from threading import Thread
from phonebook import Phonebook

class ClientHandler(Thread):
    """Handles a client for the online phonebook."""
    def __init__(self, client):
        Thread.__init__(self)
        self._client = client
        self._phonebook = Phonebook()
    def run(self):
        menuString = "\nPlease select one of the following:\n1) Look up a phone number\n2) Enter a new name and number\n3) Display phonebook\n\nOr just press ENTER to disconnect..."
        self._client.send(bytes(menuString, CODE))
        while True:
            message = decode(self._client.recv(BUFSIZE), CODE)
            if not message:
                print('Client disconnected')
                self._client.close()
                break
            elif message == "1":
                self._client.send(bytes("\nEnter the name to search for:", CODE))
                name = decode(self._client.recv(BUFSIZE), CODE)
                number = self._phonebook.findNumber(name) + "\n"
                self._client.send(bytes("\n" + name + "\'s number: " + number + menuString, CODE))
            elif message == "2":
                self._client.send(bytes("\nEnter the name to add to the phonebook (cannot contain the # symbol):", CODE))
                name = decode(self._client.recv(BUFSIZE), CODE)
                if "#" in name:
                    self._client.send(bytes("\nInvalid input.\n" + menuString, CODE))
                else:
                    self._client.send(bytes("\nEnter " + name + "\'s 10-digit number (numbers only... no spaces, letters, or other characters):", CODE))
                    number = decode(self._client.recv(BUFSIZE), CODE)
                    if number.isdigit() and len(number) == 10:
                        if self._phonebook.addNumber(name + "#" + number):
                            self._client.send(bytes("\nName and number added.\n" + menuString, CODE))
                        else:
                            self._client.send(bytes("\n" + name + " already exists in phonebook.\n" + menuString, CODE))
                    else:
                        self._client.send(bytes("\nInvalid input.\n" + menuString, CODE))
            elif message == "3":
                self._client.send(bytes("\n" + str(self._phonebook) + "\n" + menuString, CODE))
            else:
                self._client.send(bytes("\nInvalid input.\n" + menuString, CODE))

HOST = 'localhost'
PORT = 21567
ADDRESS = (HOST, PORT)
CODE = 'ascii'
BUFSIZE = 1024

server = socket(AF_INET, SOCK_STREAM)
server.bind(ADDRESS)
server.listen(5)

while True:
    print('Waiting for connection . . .')
    client, address = server.accept()
    print('... connected from:', address)
    handler = ClientHandler(client)
    handler.start()
