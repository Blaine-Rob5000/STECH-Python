"""
Student:  Robin G. Blaine
Date:     November 20, 2017
Class:   _Python Programming

Assignment (Module 3, Chapter 10, Project 7):
Modify the network application for therapy discussed in this chapter so
that it handles multiple clients. Each client has its own doctor object.
The program saves teh doctor object for a client when it disconnects.
Each doctor object should be associated with a patient user name. When
a new patient logs in, a new doctor is created. But when an existing
patient logs in, its doctor object is read from a file having that patient's
user name. Each doctor object should have its own history list of a
patient's inputs for generating replies that refer to earlier conversations.


File: doctorclient.py

Client for a therapy session.
"""

from socket import *
from codecs import decode
import sys

HOST = 'localhost'
PORT = 21567
BUFSIZE = 1024
ADDRESS = (HOST, PORT)
CODE = 'ascii'

server = socket(AF_INET, SOCK_STREAM)
server.connect(ADDRESS)
print(decode(server.recv(BUFSIZE), CODE))
name = input('> ')
if not name:
    sys.exit("Session ended.")
server.send(bytes(name, CODE))
print(decode(server.recv(BUFSIZE), CODE))

while True:
    message = input('> ')
    if not message:
        break
    server.send(bytes(message, CODE))
    reply = decode(server.recv(BUFSIZE), CODE)
    if not reply:
        print("Server disconnected")
        break
    print(reply)
server.close()
