"""
Student:  Robin G. Blaine
Date:     November 20, 2017
Class:   _Python Programming

Assignment (Module 3, Chapter 10, Project 7):
Modify the network application for therapy discussed in this chapter so
that it handles multiple clients. Each client has its own doctor object.
The program saves teh doctor object for a client when it disconnects.
Each doctor object should be associated with a patient user name. When
a new patient logs in, a new doctor is created. But when an existing
patient logs in, its doctor object is read from a file having that patient's
user name. Each doctor object should have its own history list of a
patient's inputs for generating replies that refer to earlier conversations.


File: doctorserver.py

Server for a therapy session. Handles multiple clients
concurrently.
"""

from socket import *
from codecs import decode
from threading import Thread
from doctor import Doctor

class ClientHandler(Thread):
    """Handles a session between a doctor and a patient."""
    def __init__(self, client, dr):
        Thread.__init__(self)
        self._client = client
        self._dr = dr

    def run(self):
        self._client.send(bytes("Enter your name...", 'ascii'))
        patient = decode(self._client.recv(BUFSIZE), 'ascii')
        dr.loadHistory(patient)
        self._client.send(bytes(self._dr.greeting(patient), 'ascii'))
        while True:
            message = decode(self._client.recv(BUFSIZE), 'ascii')
            if not message:
                print('Client disconnected')
                self._client.close()
                break
            else:
                self._client.send(bytes(self._dr.reply(message), 'ascii'))

HOST = 'localhost'
PORT = 21567
ADDRESS = (HOST, PORT)
BUFSIZE = 1024

server = socket(AF_INET, SOCK_STREAM)
server.bind(ADDRESS)
server.listen(5)

while True:
    print('Waiting for connection . . .')
    client, address = server.accept()
    print('... connected from:', address)
    dr = Doctor()
    handler = ClientHandler(client, dr)
    handler.start()
