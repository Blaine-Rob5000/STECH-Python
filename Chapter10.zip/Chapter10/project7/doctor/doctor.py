"""
Student:  Robin G. Blaine
Date:     November 20, 2017
Class:   _Python Programming

Assignment (Module 3, Chapter 10, Project 7):
Modify the network application for therapy discussed in this chapter so
that it handles multiple clients. Each client has its own doctor object.
The program saves teh doctor object for a client when it disconnects.
Each doctor object should be associated with a patient user name. When
a new patient logs in, a new doctor is created. But when an existing
patient logs in, its doctor object is read from a file having that patient's
user name. Each doctor object should have its own history list of a
patient's inputs for generating replies that refer to earlier conversations.


Module: doctor.py
Project 10.7

Data model class to conduct an interactive session of
nondirective psychotherapy.

Includes a history of earlier patient inputs.
"""

import random

class Doctor(object):
    """A doctor gives a greeting, replies to patient's statements,
    and gives a signoff."""

    HEDGES = ("Please tell me more.",
              "Many of my patients tell me the same thing.",
              "Please coninue.")

    QUALIFIERS = ("Why do you say that ",
                  "You seem to think that ",
                  "Can you explain why ")

    REPLACEMENTS = {"I":"you", "ME":"you", "MY":"your",
                    "WE":"you", "US":"you", "MINE":"yours",
                    "YOURS":"mine"}

    def __init__(self):
        self._history = []

    def loadHistory(self, patient):
        """Loads the file (if any) for the patient."""
        self._patientName = patient
        self._filename = patient + '.txt'
        try:
            readFile = open(self._filename, 'r')
            print("Patient file opened...")
            for line in readFile:
                self._history.append(line[:-1])
                print(line[:-1])
        except:
            print("Patient " + patient + " not found. Creating new patient file...")
            writeFile = open(self._filename, 'w')
            writeFile.close()
            return
          
    def updateHistory(self):
        """Updates the patient's history."""
        writeFile = open(self._filename, 'w')
        for line in self._history:
            writeFile.write(line + '\n')
        writeFile.close()
        

    def greeting(self, patient):
        """Returns a greeting."""
        greeting = "Good morning, " + patient + ". I hope you are well today.\n" + "What can I do for you?"
        return greeting

    def signoff(self):
        """Saves the patient's history and returns a signoff message."""
        self.updateHistory()
        return "Have a nice day!"

    def reply(self, sentence):
        """Implements three different reply strategies."""
        probability = random.randint(1, 3)
        if probability == 1:
            result = random.choice(Doctor.HEDGES)
        elif probability == 2 and len(self._history) > 3:
            result = "Earlier you said that " + self._changePerson(random.choice(self._history))
        else:
            result = random.choice(Doctor.QUALIFIERS) + self._changePerson(sentence)
        self._history.append(sentence)
        self.updateHistory()
        return result

    def _changePerson(self, sentence):
        """Replaces first person pronouns with second person
        pronouns."""
        words = sentence.split()
        replyWords = []
        for word in words:
            replyWords.append(Doctor.REPLACEMENTS.get(word.upper(), word))
        return " ".join(replyWords)
      
