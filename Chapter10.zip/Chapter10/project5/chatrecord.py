"""
Student:  Robin G. Blaine
Date:     November 14, 2017
Class:   _Python Programming

Assignment (Module 3, Chapter 10, Project 5):
Modify the multi-client chat room application discussed in this chapter
so that it maintains the chat record in a text file. The record should load
the text from the file at instantiation and save each message as it is
received.


From textbook:  chat record object for a multi-client chat room
"""

class ChatRecord(object):

    def __init__(self):
        self.data = []
        self.filename = 'chatrecord.txt'
        self.load()

    def __str__(self):
        if len(self.data) == 0:
            return 'No messages yet!'
        else:
            return '\n'.join(self.data)

    def add(self, message):
        self.data.append(message)
        writeFile = open(self.filename, 'w')
        for line in self.data:
            writeFile.write(line + '\n')
        writeFile.close()

    def load(self):
        readFile = open(self.filename, 'r')
        for line in readFile:
            self.data.append(line[:-1])
