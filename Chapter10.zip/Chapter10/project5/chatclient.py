"""
Student:  Robin G. Blaine
Date:     November 14, 2017
Class:   _Python Programming

Assignment (Module 3, Chapter 10, Project 5):
Modify the multi-client chat room application discussed in this chapter
so that it maintains the chat record in a text file. The record should load
the text from the file at instantiation and save each message as it is
received.


From the textbook:  client for a multi-client chat room
"""

from socket import *
from codecs import decode

HOST = 'localhost' 
PORT = 5000
BUFSIZE = 1024
ADDRESS = (HOST, PORT)
CODE = 'ascii'
server = socket(AF_INET, SOCK_STREAM)
server.connect(ADDRESS)
print(decode(server.recv(BUFSIZE), CODE))
name = input('Enter your name: ')
server.send(bytes(name, CODE))

while True:
    record = decode(server.recv(BUFSIZE), CODE)
    if not record:
        print('No record: Server disconnected')
        break
    print(record)
    message = input('> ')
    if not message:
        print('Chat ended: Server disconnected')
        break
    server.send(bytes(message, CODE))
server.close()
