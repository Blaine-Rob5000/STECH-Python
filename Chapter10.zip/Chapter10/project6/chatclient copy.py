"""
Student:  Robin G. Blaine
Date:     November 20, 2017
Class:   _Python Programming

Assignment (Module 3, Chapter 10, Project 6):
In the multi-client chat room application, a client must send a message
to the server to receive a record of the chat. Suggest and implement a
way for the client to receive the chat record even if it has nothing
significant to say.


From the textbook:  client for a multi-client chat room
"""

from socket import *
from codecs import decode

HOST = 'localhost' 
PORT = 5000
BUFSIZE = 1024
ADDRESS = (HOST, PORT)
CODE = 'ascii'
server = socket(AF_INET, SOCK_STREAM)
server.connect(ADDRESS)
print(decode(server.recv(BUFSIZE), CODE))
name = input('Enter your name: ')
print('\nPress ENTER to receive chat record; enter Q at prompt to quit chat client.\n')
server.send(bytes(name, CODE))

while True:
    record = decode(server.recv(BUFSIZE), CODE)
    if not record:
        print('No record: Server disconnected')
        break
    print(record)
    message = input('> ')
    if not message:
        message = '...'
    elif message[0].upper() == 'Q':
        print('Chat ended: Server disconnected')
        break
    server.send(bytes(message, CODE))
server.close()
