"""
Student:  Robin G. Blaine
Date:     November 20, 2017
Class:   _Python Programming

Assignment (Module 3, Chapter 10, Project 6):
In the multi-client chat room application, a client must send a message
to the server to receive a record of the chat. Suggest and implement a
way for the client to receive the chat record even if it has nothing
significant to say.


From textbook:  chat record object for a multi-client chat room
"""

class ChatRecord(object):

    def __init__(self):
        self.data = []
        self.filename = 'chatrecord.txt'
        self.load()

    def __str__(self):
        if len(self.data) == 0:
            return 'No messages yet!'
        else:
            return '\n'.join(self.data)

    def add(self, message):
        self.data.append(message + '\n')
        writeFile = open(self.filename, 'w')
        for line in self.data:
            writeFile.write(line)
        writeFile.close()

    def load(self):
        readFile = open(self.filename, 'r')
        for line in readFile:
            self.data.append(line)
