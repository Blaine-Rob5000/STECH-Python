"""
Student:  Robin G. Blaine
Date:     October 31, 2017
Class:   _Python Programming

Assignment (Module 3, Chapter 8, Project 5):
Develop a terminal-based program that allows a bank manager to manipulate
the accounts in a bank. This menu-driven program should include all of the
relevant options, such as adding a new account, removing an account, and
editing an account.

Pseudocode:

"""

import pickle
from bank import SavingsAccount, Bank

def menuInput(menuRange):
    choice = ""
    while choice not in range("1", menuRange):
        choice = input("Enter selection:")
        if choice not in range("1", menuRange):
            print("Invalid selection. Enter a number between 1 and",
                  menuRange, "\b...\n")           
    return choice

def mainMenu():
    print("\nSelect an option:")
    print("  1) List accounts")
    print("  2) Add an account")
    print("  3) Remove an account")
    print("  4) Edit an account")
    print("  5) Exit program\n")
    menuChoice = menuInput("5")
    return menuChoice
\n
def listAccounts(bank):
    print("\n", bank, "\n")

def addAccount(bank):
    pin = int(input("Enter a new account PIN: "))
    while pin in bank:
        print("\nThat account already exists.")
        pin = int(input("\nEnter a new account PIN:"))
    name = input("Enter the customer's name:")
    bank.add(SavingsAccount(name, pin))
    return bank

def removeAccount(bank):
    account = 0
    while account not in bank:
        account = int(input("\nEnter account PIN to remove:"))
        if account not in bank:
            print("\nInvalid account PIN.")
    print("Remove this account:")
    print(bank.get(account))
    yesNo = ""
    while yesNo not in ("Y", "N"):
        yesNo = input("Enter Y or N:")
        yesNo = yesNo.upper()
    if yesNo = "Y":
        bank.remove(account)
    return bank

def editMenu():
    print("\nSelect an option:")
    print("  1) Change name")
    print("  2) Change balance")
    print("  3) Return to Main Menu\n")
    menuChoice = menuInput("3")
    return menuChoice

def editAccount(bank):
    account = selectAccount(bank)
    returnToMainMenu = "3"
    option = ""
    while option != returnToMainMenu:
        option = editMenu()
        if option = "1":
            
    return bank

def main():
    # create and populate a bank
    bank = Bank()
    for i in range(10):
        bank.add(SavingsAccout('Name' + str(i + 1),
                               str(1000 + i),
                               100.00))

    exitProgram = "5"
    option = ""
    while option != exitProgram:
        option = mainMenu()
        if option = "1":
            listAccounts(bank)
        elif option = "2":
            bank = addAccount(bank)
        elif option = "3":
            removeAccount(bank)
        elif option = "4":
            bank = editAccount(bank)

    print("\n\nGoodbye!")

main()


    
