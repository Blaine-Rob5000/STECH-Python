"""
Student:  Robin G. Blaine
Date:     November 2, 2017
Class:   _Python Programming

SavingsAccount and Bank classes from student data...

Assignment (Module 3, Chapter 8, Project 5):
Develop a terminal-based program that allows a bank manager to manipulate
the accounts in a bank. This menu-driven program should include all of the
relevant options, such as adding a new account, removing an account, and
editing an account.
"""

import pickle

class SavingsAccount(object):
    """This class represents a savings account
    with the owner's name, PIN, and balance."""

    RATE = 0.02
        
    def __init__(self, name, pin, balance = 0.0):
        self._name = name
        self._pin = pin
        self._balance = balance

    def __str__(self):
        result =  'Name:    ' + self._name + '\n' 
        result += 'PIN:     ' + self._pin + '\n' 
        result += 'Balance: ' + str(self._balance)
        return result

    def getBalance(self):
        return self._balance

    def getName(self):
        return self._name

    def getPin(self):
        return self._pin

    def deposit(self, amount):
        """Deposits the given amount."""
        self._balance += amount
        return self._balance

    def withdraw(self, amount):
        """Withdraws the given amount.
        Returns None if successful, or an
        error message if unsuccessful."""
        if amount < 0:
            return 'Amount must be >= 0'
        elif self._balance < amount:
            return 'Insufficient funds'
        else:
            self._balance -= amount
            return None

    def computeInterest(self):
        """Computes, deposits, and returns the interest."""
        interest = self._balance * SavingsAccount.RATE
        self.deposit(interest)
        return interest

class Bank(object):
    """This class represents a bank as a dictionary of
    accounts.  An optional file name is also associated
    with the bank, to allow transfer of accounts to and
    from permanent file storage."""

    def __init__(self, fileName = None):
        """Creates a new dictionary to hold the accounts.
        If a file name is provided, loads the accounts from
        a file of pickled accounts."""
        self._accounts = {}
        self.fileName = fileName
        if fileName != None:
            fileObj = open(fileName, 'rb')
            while True:
                try:
                    account = pickle.load(fileObj)
                    self.add(account)
                except(EOFError):
                    fileObj.close()
                    break

    def add(self, account):
        """Inserts an account using its PIN as a key."""
        self._accounts[account.getPin()] = account

    def remove(self, pin):
        return self._accounts.pop(pin, None)

    def get(self, pin):
        return self._accounts.get(pin, None)
        
    def computeInterest(self):
        """Computes interest for each account and
        returns the total."""
        total = 0
        for account in self._accounts.values():
            total += account.computeInterest()
        return total

    def __str__(self):
        """Return the string rep of the entire bank."""
        return '\n'.join(map(str, self._accounts.values()))

    def save(self, fileName = None):
        """Saves pickled accounts to a file.  The parameter
        allows the user to change file names."""
        if fileName != None:
            self.fileName = fileName
        elif self.fileName == None:
            return
        fileObj = open(self.fileName, 'wb')
        for account in self._accounts.values():
            pickle.dump(account, fileObj)
        fileObj.close()

def menuInput(menuRange):
    """Input a menu choice between 1 and menuRange."""
    choice = " "
    while ord(choice) not in range(49, ord(menuRange) + 1):
        choice = input("\nEnter selection: ")
        if choice == "":
            choice = " "
        if ord(choice) not in range(49, ord(menuRange) + 1):
            print("Invalid selection. Enter a number between 1 and",
                  menuRange, "...\n")          
    return choice

def mainMenu():
    """Main menu."""
    print("\nSelect an option:")
    print("  1) List accounts")
    print("  2) Add an account")
    print("  3) Remove an account")
    print("  4) Edit an account")
    print("  5) Exit program")
    menuChoice = menuInput("5")
    return menuChoice

def chooseAccount(bank):
    """Select an existing account."""
    account = ""
    while account not in bank._accounts:
        account = input("\nEnter account PIN: ")
        if account not in bank._accounts:
            print("\nInvalid account PIN.")
    return account

def listAccounts(bank):
    """List existing accounts."""
    print("")
    for account in bank._accounts:
        print(bank.get(account))
        print("")

def addAccount(bank):
    """Add a new account."""
    pin = input("\nEnter a new 4-digit account PIN: ")
    while (pin in bank._accounts) or (int(pin) > 9999) or (int(pin) < 1000):
        print("\nPIN exists or is invalid.")
        pin = input("\nEnter a new account PIN: ")
    name = input("\nEnter the customer's name: ")
    bank.add(SavingsAccount(name, pin))
    print("")
    print("New account:")
    print(bank.get(pin))
    return bank

def removeAccount(bank):
    """Remove an existing account."""
    account = chooseAccount(bank)
    print("\nRemove this account?:")
    print(bank.get(account))
    yesNo = ""
    while yesNo not in ("Y", "N"):
        yesNo = input("\nEnter Y or N: ")
        yesNo = yesNo.upper()
    if yesNo == "Y":
        bank.remove(account)
        print("\nAccount removed.")
    else:
        print("\nAccount not removed.")
    return bank

def editMenu():
    """Menu to edit an account."""
    print("\nSelect an option:")
    print("  1) Make Deposit")
    print("  2) Make withdrawal")
    print("  3) Return to Main Menu")
    menuChoice = menuInput("3")
    return menuChoice

def editAccount(bank):
    """Function to edit an account."""
    account = chooseAccount(bank)
    print("\nEdit account:")
    print(bank.get(account))
    option = editMenu()
    if option == "1":
        depositAmount = float(input("\nEnter the amount to deposit: $"))
        bank._accounts[account].deposit(depositAmount)
    if option == "2":
        withdrawAmount = float(input("\nEnter the amount to withdraw: $"))
        bank._accounts[account].withdraw(withdrawAmount)
    print("\nNew balance:")
    print(bank.get(account))
    return bank

def main():
    """Main function."""
    # create and populate a bank
    bank = Bank()
    for i in range(10):
        bank.add(SavingsAccount('Name' + str(i + 1), str(1000 + i), 100.00))
    option = ""
    exitProgram = "5"
    while option != exitProgram:
        option = mainMenu()
        if option == "1":
            listAccounts(bank)
        elif option == "2":
            bank = addAccount(bank)
        elif option == "3":
            removeAccount(bank)
        elif option == "4":
            bank = editAccount(bank)
    print("\n\nGoodbye!")

main()

    
