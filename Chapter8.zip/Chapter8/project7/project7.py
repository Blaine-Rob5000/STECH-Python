"""
Student:  Robin G. Blaine
Date:     October 30, 2017
Class:   _Python Programming

Assignment (Module 3, Chapter 8, Project 6):

Pseudocod:

"""

