"""
Student:  Robin G. Blaine
Date:     November 3, 2017
Class:   _Python Programming

Assignment (Module 3, Chapter 8, Project 7):
Develop a Library class that can manage the books and patrons from Project 6.
This class should be include methods for:
  adding a patron or book
  removing a patron or book
  finding a patron or book
"""

import random

MAXIMUM = 3

class Book(object):
    """This class represents a book."""

    def __init__(self, title, author):
        self._title = title
        self._author = author
        self._patron = None
        self._waitingList = []

    def __str__(self):
        result =  'Title: ' + self._title + '\n'
        result += 'Author: ' + self._author + '\n'
        result += 'Currently on loan to: '
        if self._patron == None:
            result += 'NA\n'
        else:
            result += self._patron.getName() + '\n'
        result += 'Waiting list:'
        if len(self._waitingList) == 0:
            result += '\n  None'
        else:
            for name in range(len(self._waitingList)):
                result += '\n  ' + self._waitingList[name].getName()
        return result

    def getTitle(self):
        return self._title

    def getAuthor(self):
        return self._author

    def getPatron(self):
        return self._patron

    def getWaitingList(self):
        return self._waitingList

    def loanBook(self, patron):
        if (self._patron == None) and (patron.getNumberOfBooks() < MAXIMUM):
            self._patron = patron
            patron.addBook(self)
            if patron in self._waitingList:
                self._waitingList.remove(patron)
        elif patron not in self._waitingList:
            self._waitingList.append(patron)
            print('Book:  ' + patron.getName() +
                  ' added to the waiting list for ' + self._title)
        else:
            print('Book:  ' + patron.getName() +
                  ' already on waiting list for ' + self._title)

    def returnBook(self, patron):
        if self._patron == patron:
            patron.removeBook(self)
            print('Book: ' + patron.getName() + ' returned ' + self._title)
            self._patron = None
            if len(self._waitingList) > 0:
                for newPatron in self._waitingList:
                    if newPatron.getNumberOfBooks() < MAXIMUM:
                        self._patron = newPatron
                        self._waitingList.remove(newPatron)
                        newPatron.addBook(self)
                        print('Book: ' + newPatron.getName() + ' borrowed '
                              + self._title + '; removed from waiting list.')
        else:
            print('Book: ' + patron.getName() + ' does not have ' +
                  self._title)

class Patron(object):
    """This class represents a library patron."""

    def __init__(self, name):
        self._name = name
        self._books = []

    def __str__(self):
        result =  'Patron Name: ' + self._name + '\n'
        result += 'Books currently on loan to this patron:'
        if len(self._books) == 0:
            result += '\n  None'
        else:
            for book in range(len(self._books)):
                result += '\n  ' + self._books[book].getTitle()
        return result

    def getName(self):
        return self._name

    def getBooks(self):
        return self._books

    def getNumberOfBooks(self):
        return len(self._books)

    def addBook(self, book):
        if len(self._books) < MAXIMUM:
            self._books.append(book)
            print('Patron: ' + self._name + ' borrowed ' + book.getTitle())
        else:
            print('Patron: ' + self._name +
                  ' already has the maximum number of books on loan.')

    def removeBook(self, book):
        if book in self._books:
            self._books.remove(book)
            print('Patron: ' + self._name + ' returned ' + book.getTitle())
        else:
            print('Patron: ' + self._name + ' does not have ' +
                  book.getTitle())

class Library(object):
    """This class represents a library to handle patrons and books."""

    def __init__(self):
        self._bookList = []
        self._patronList = []

    def __str__(self):
        result = 'Books:\n\n'
        for book in self._bookList:
            result += str(book) + '\n\n'
        result += '\n\nPatrons:\n\n'
        for patron in self._patronList:
            result += str(patron) + '\n\n'
        return result

    def addBook(self, book):
        self._bookList.append(book)
        print('Library:  ' + book.getTitle() + ' added to library.')

    def removeBook(self, book):
        if book in self._bookList:
            self._bookList.remove(book)
            print('Library:  ' + book.getTitle() + ' removed from library.')
        else:
            print('Library:  ' + book.getTitle() + ' not in library.')

    def findBook(self, book):
        if book in self._bookList:
            print('Book found!')
            print(book)
            return True
        else:
            print(book.getTitle() + ' not found...')
            return False

    def getBookList(self):
        return self._bookList

    def addPatron(self, patron):
        self._patronList.append(patron)

    def removePatron(self, patron):
        if patron in self._patronList:
            self._patronList.remove(patron)
            print('Library:  ' + patron.getName() + ' removed from library.')
        else:
            print('Library:  ' + patron.getName() + ' not a patron.')

    def findPatron(self, patron):
        if book in self._patronList:
            print('Patron found!')
            print(patron)
            return True
        else:
            print(patron.getName() + ' not found...')
            return False

    def getPatronList(self):
        return self._patronList

def main():
    """Main function."""

    # create library
    library = Library()

    # create and add books to library
    library.addBook(Book('Harry Potter', 'J.K. Rowling'))
    library.addBook(Book('The Lord of the Rings', 'J.R.R. Tolkien'))
    library.addBook(Book('The Crystal Shard', 'R.A. Salvatore'))
    library.addBook(Book('Cavernss of Socrates', 'Dennis L. McKiernan'))
    library.addBook(Book('War and Peace', 'Leo Tolstoy'))
    library.addBook(Book('Beneath the Bleachers', 'Seymore Butts'))
    library.addBook(Book('A Mad Dash for the Outhouse', 'Willie Maykit'))
    library.addBook(Book('On the Yellow River', 'I.P. Freely'))
    library.addBook(Book('Will Trump be Impeached?', 'Betty Izz'))
    library.addBook(Book('Did Trump Collude?', 'Hugh Betcha'))

    # create and add patrons to library
    library.addPatron(Patron('Robin Blaine'))
    library.addPatron(Patron('Rocky Mazarow'))
    library.addPatron(Patron('Greg Davis'))
    library.addPatron(Patron('Stan Lee'))
    library.addPatron(Patron('Godzilla'))

    # test library
    print(library)
    pressEnterToContinue = input('\nPress ENTER to continue...')
    print("\n")

    # randomly loan books
    print("\n\nRandomly loaning books...\n")
    for x in range(20):
        book = random.choice(library.getBookList())
        patron = random.choice(library.getPatronList())
        if book not in patron.getBooks():
            book.loanBook(patron)
            print("\n")

    print("\n\n")
    print(library)
    pressEnterToContinue = input('\nPress ENTER to continue...')
    print("\n\n")

    # randomly return books
    print("\n\nRandomly returning books...\n")
    for x in range(10):
        patron = random.choice(library.getPatronList())
        if patron.getNumberOfBooks() > 0:
            book = random.choice(patron.getBooks())
            book.returnBook(patron)
            print("")

    print("\n")
    print(library)

main()
