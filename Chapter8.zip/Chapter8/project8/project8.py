"""
Student:  Robin G. Blaine
Date:     November 3, 2017
Class:   _Python Programming

Assignment (Module 3, Chapter 8, Project 7):
Develop a Manager class that provides a menu-driven command processor for
managing a library of the type developed in Project 7.
"""

import random

MAXIMUM = 3

class Book(object):
    """This class represents a book."""

    def __init__(self, title, author):
        """Initialize Book."""
        self._title = title
        self._author = author
        self._patron = None
        self._waitingList = []

    def __str__(self):
        """Returns a string describing the book's properties."""
        
        result =  'Title: ' + self._title + '\n'
        result += 'Author: ' + self._author + '\n'
        result += 'Currently on loan to: '
        if self._patron == None:
            result += 'NA\n'
        else:
            result += self._patron.getName() + '\n'
        result += 'Waiting list:'
        if len(self._waitingList) == 0:
            result += '\n  None'
        else:
            for name in range(len(self._waitingList)):
                result += '\n  ' + self._waitingList[name].getName()
        return result


    def getTitle(self):
        """Returns the book's title."""
        
        return self._title


    def getAuthor(self):
        """Returns the book's author."""
        
        return self._author


    def getPatron(self):
        """Returns the patron object currently borrowing the book."""
        
        return self._patron


    def getWaitingList(self):
        """Returns the list of patrons waiting to check out the book."""
        
        return self._waitingList


    def removeFromWaitingList(patron):
        """Removes a patron from the book's waiting list."""
        
        if patron in self._waitingList:
            self._waitingList.remove(patron)
            print('Book:  Patron removed from waiting list')


    def loanBook(self, patron):
        """Loans the book to a patron.  If the book is already on loan
           or if the patron is currently borrowing the maximum allowed
           number of books, the patron is, instead, placed on the book's
           waiting list."""
        
        if (self._patron == None) and (patron.getNumberOfBooks() < MAXIMUM):
            self._patron = patron
            patron.addBook(self)
            if patron in self._waitingList:
                self._waitingList.remove(patron)
        elif patron not in self._waitingList:
            self._waitingList.append(patron)
            print('Book:  ' + patron.getName() +
                  ' added to the waiting list for ' + self._title)
        else:
            print('Book:  ' + patron.getName() +
                  ' already on waiting list for ' + self._title)


    def returnBook(self, patron):
        """Returns the book from the patron if that patron is currently
           borrowing it and automatically loans the book to the next
           eligible patron (if any) on the book's waiting list."""
        
        if self._patron == patron:
            patron.removeBook(self)
            print('Book: ' + patron.getName() + ' returned ' + self._title)
            self._patron = None
            if len(self._waitingList) > 0:
                for newPatron in self._waitingList:
                    if newPatron.getNumberOfBooks() < MAXIMUM:
                        self._patron = newPatron
                        self._waitingList.remove(newPatron)
                        newPatron.addBook(self)
                        print('Book: ' + newPatron.getName() + ' borrowed '
                              + self._title + '; removed from waiting list.')
        else:
            print('Book: ' + patron.getName() + ' does not have ' +
                  self._title)


class Patron(object):
    """This class represents a library patron."""

    def __init__(self, name):
        """Initialize the Patron object."""
        
        self._name = name
        self._books = []


    def __str__(self):
        """Returns a string describing the patron's properties."""
        
        result =  'Patron Name: ' + self._name + '\n'
        result += 'Books currently on loan to this patron:'
        if len(self._books) == 0:
            result += '\n  None'
        else:
            for book in range(len(self._books)):
                result += '\n  ' + self._books[book].getTitle()
        return result


    def getName(self):
        """Returns the patron's name."""
        
        return self._name


    def getBooks(self):
        """Returns the list of books currently on loan to the patron as
           a list of book objects."""
        
        return self._books


    def getNumberOfBooks(self):
        """Returns the number of books currently on loan to the patron."""
        
        return len(self._books)


    def addBook(self, book):
        """Attempts to borrow a book."""
        
        if len(self._books) < MAXIMUM:
            self._books.append(book)
            print('Patron: ' + self._name + ' borrowed ' + book.getTitle())
        else:
            print('Patron: ' + self._name +
                  ' already has the maximum number of books on loan.')


    def removeBook(self, book):
        """Return a book."""
        
        if book in self._books:
            self._books.remove(book)
            print('Patron: ' + self._name + ' returned ' + book.getTitle())
        else:
            print('Patron: ' + self._name + ' does not have ' +
                  book.getTitle())


class Library(object):
    """This class represents a library to handle patrons and books."""

    def __init__(self):
        """Initialize Library object."""
        
        self._bookList = []
        self._patronList = []


    def __str__(self):
        """Returns a string describing the library's properties."""
        
        result = 'Books:\n\n'
        for book in self._bookList:
            result += str(book) + '\n\n'
        result += '\n\nPatrons:\n\n'
        for patron in self._patronList:
            result += str(patron) + '\n\n'
        return result


    def addBook(self, book):
        """Adds a book to the library."""
        
        self._bookList.append(book)
        print('Library:  ' + book.getTitle() + ' added to library.')


    def removeBook(self, book):
        """Removes a book from the library."""
        
        if book in self._bookList:
            self._bookList.remove(book)
            print('Library:  ' + book.getTitle() + ' removed from library.')
        else:
            print('Library:  ' + book.getTitle() + ' not in library.')


    def findBook(self, title):
        """Finds a book in the library."""
        
        for book in self._bookList:
            if book.getTitle() == title:
                print('\nBook found!')
                print(book)
                return True
        print(title + ' not found...')
        return False


    def getBookList(self):
        """Returns a list of all books in the library as a list of
           book objects."""
        
        return self._bookList


    def addPatron(self, patron):
        """Adds a patron to the library."""
        
        self._patronList.append(patron)


    def removePatron(self, patron):
        """Removes a patron from the library."""
        
        if patron.getNumberOfBooks() > 0:
            print('\nLibrary:  That patron has books on loan! ' +
                  'Please return or remove those books before removing ' +
                  'this patron.')
            return
        if patron in self._patronList:
            for book in self._bookList:
                if patron in book.getWaitingList():
                    book.removeFromWaitingList(patron)
            self._patronList.remove(patron)
            print('Library:  ' + patron.getName() + ' removed from library.')
        else:
            print('Library:  ' + patron.getName() + ' not a patron.')


    def findPatron(self, name):
        """Finds a patron in the library."""
        
        for patron in self._patronList:
            if patron.getName() == name:
                print('\nLibrary:  Patron found!')
                print(patron)
                return True
        print('Library:  Patron ' + name + ' not found.')
        return False

    def getPatronList(self):
        """Returns a list of patrons in the library as a list of
           patron objects."""
        
        return self._patronList


class LibraryManager(object):
    """This class provides a menu-driven command processor for managing
       the library class."""

    def __init__(self, library):
        """Initialize the Manager object."""
        self._library = library


    def __str__(self):
        """Returns a string describing the manager's properties."""
        return 'Library manager.'


    def getMenuChoice(self, first, last):
        """Select a menu option in the number range of first to last."""
        
        choiceString = ''
        choice = -1
        while choiceString == '':
            choiceString = input('\nEnter menu choice (' + str(first) +
                                 ' - ' + str(last) +'): ')
            if is_int(choiceString):
                choice = int(choiceString)
            if choice not in range(first, last):
                print('\nInvalid menu selection.')
                choiceString = ''
        return choice


    def editBooksMenu(self):
        """Add, remove, or find a book or list all books in the library."""
        
        print('\nEdit Books Menu:')
        print('1) Add a book to the library.')
        print('2) Remove a book from the library.')
        print('3) Find a book in the library.')
        print('4) List all books in the library.')
        print('5) Return to the main menu.')

        menuFirst = 1
        menuLast  = 5
        choice = getMenuChoice(menuFirst, menuLast)










    def editPatronsMenu(self):
        """Add, remove, or find a patron or list all patrons of the library."""

        print('\nEdit Patrons Menu:')
        print('1) Add a patron to the library.')
        print('2) Remove a patron from the library.')
        print('3) Find a patron of the library.')
        print('4) List all patrons of the library.')
        print('5) Return to the main menu.')

        menuFirst = 1
        menuLast  = 5
        choice = getMenuChoice(menuFirst, menuLast)










    def mainMenu(self):
        """Displays the manager's main menu and returns the selection."""

        print('\nLibrary Manager Main Menu:')
        print('1) Loan a book.')
        print('2) Return a book.')
        print('3) Edit books.')
        print('4) Edit patrons.')
        print('5) Exit Manager.')
        
        menuFirst = 1
        menuLast  = 5
        choice = getMenuChoice(menuFirst, menuLast)
        return choice










    def managerAddBook(self, library):
        """Add a book to the library being managed."""
        
        title = ''
        print('\nEnter the title of the book to be added (or just press ' +
              'ENTER to return to the main menu).')
        title = input('  Title: ')
        if title == '': return
        print('\nEnter the author of the book (or just press ENTER ' +
              'to return to the main menu).')
        author = input('  Author: ')
        if author == '': return
        print("")
        library.addBook(Book(title, author))
        print('Manager:  Book added!')


    def managerRemoveBook(self, library):
        """Remove a book from the library being managed."""
        
        bookList = library.getBookList()
        numberOfBooks = len(bookList)
        if numberOfBooks == 0:
            print('\nNo books in library!')
            return
        bookNumber = 1
        for book in bookList:
            print('Book number ' + str(bookNumber))
            print(str(book) + '\n')
            bookNumber += 1
        choice = -1
        while choice not in range(bookNumber):
            print('\nEnter the number of the book to be removed (or ' +
                  'just press ENTER to return to the main menu).')
            choiceString = input('  Book number: ')
            if choiceString == '': return
            if is_int(choiceString):
                choice = int(choiceString) - 1
            else:
                print('\nInvalid entry.\n')
        library.removeBook(bookList[choice])
        print('Book removed!')


    def managerFindBook(self, library):
        """Finds a book in the library being managed."""
        
        bookName = ''
        print('\nEnter the name of the book to find (or just press ' +
              'ENTER to return to the main menu).')
        bookName = input('  Book name: ')
        if bookName == '': return
        library.findBook(bookName)


    def managerBookList(self, library):
        """Lists the books in the library being managed."""
        
        bookList = library.getBookList()
        for book in bookList:
            print('\n' + str(book))


    def managerAddPatron(library):
        """Add a patron to the library being managed."""
        
        name = ''
        print('\nEnter the name of the patron to be added (or just press ' +
              'ENTER to return to the main menu).')
        name = input('  Name: ')
        if name == '': return
        print("")
        library.addPatron(Patron(name))
        print('Manager:  Patron added!')


    def managerRemovePatron(self, library):
        """Remove a patron from the library being managed."""
        
        patronList = library.getPatronList()
        numberOfPatrons = len(patronList)
        if numberOfPatrons == 0:
            print('\nLibrary has no patrons!')
            return
        patronNumber = 1
        for patron in patronList:
            print('Patron number ' + str(patronNumber))
            print(str(patron) + '\n')
            patronNumber += 1
        choice = -1
        while choice not in range(patronNumber):
            print('\nEnter the number of the patron to be removed (or ' +
                  'just press ENTER to return to the main menu).')
            choiceString = input('  Patron number: ')
            if choiceString == '': return
            if is_int(choiceString):
                choice = int(choiceString) - 1
            else:
                print('\nInvalid entry.\n')
        library.removePatron(patronList[choice])
        print('Patron removed!')


    def managerFindPatron(self, library):
        """Find a patron of the library being managed."""
        
        patronName = ''
        print('\nEnter the name of the patron to find (or just press ' +
              'ENTER to return to the main menu).')
        patronName = input('  Patron name: ')
        if patronName == '': return
        library.findPatron(patronName)


    def managerPatronList(self, library):
        """List the patrons of the library being managed."""
        
        patronList = library.getPatronList()
        for patron in patronList:
            print('\n' + str(patron))


    def manage(self):
        """Manages the submitted library."""

        while True:
            selection = self.mainMenu()
            if selection == 1:
                self.managerAddBook(self._library)
            elif selection == 2:
                self.managerRemoveBook(self._library)
            elif selection == 3:
                self.managerFindBook(self._library)
            elif selection == 4:
                self.managerBookList(self._library)
            elif selection == 5:
                self.managerAddPatron(self._library)
            elif selection == 6:
                self.managerRemovePatron(self._library)
            elif selection == 7:
                self.managerFindPatron(self._library)
            elif selection == 8:
                self.managerPatronList(self._library)
            else:
                break

        print('\n\nManager:  Goodbye!')










def main():
    """Main function."""

    # create library
    library = Library()

    # create and add books to library
    library.addBook(Book('Harry Potter', 'J.K. Rowling'))
    library.addBook(Book('The Lord of the Rings', 'J.R.R. Tolkien'))
    library.addBook(Book('The Crystal Shard', 'R.A. Salvatore'))
    library.addBook(Book('Cavernss of Socrates', 'Dennis L. McKiernan'))
    library.addBook(Book('War and Peace', 'Leo Tolstoy'))
    library.addBook(Book('Beneath the Bleachers', 'Seymore Butts'))
    library.addBook(Book('A Mad Dash for the Outhouse', 'Willie Maykit'))
    library.addBook(Book('On the Yellow River', 'I.P. Freely'))
    library.addBook(Book('Will Trump be Impeached?', 'Betty Izz'))
    library.addBook(Book('Did Trump Collude?', 'Hugh Betcha'))

    # create and add patrons to library
    library.addPatron(Patron('Robin Blaine'))
    library.addPatron(Patron('Rocky Mazarow'))
    library.addPatron(Patron('Greg Davis'))
    library.addPatron(Patron('Stan Lee'))
    library.addPatron(Patron('Godzilla'))

    print("")
    print(library)
    print("")

    manager = LibraryManager(library)
    manager.manage()

main()
