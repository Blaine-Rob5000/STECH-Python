"""
Student:  Robin G. Blaine
Date:     November 3, 2017
Class:   _Python Programming

Assignment (Module 3, Chapter 8, Project 7):
Develop a Manager class that provides a menu-driven command processor for
managing a library of the type developed in Project 7.
"""

import random

MAXIMUM = 3

class Book(object):
    """This class represents a book."""

    def __init__(self, title, author):
        """Initialize Book."""
        self._title = title
        self._author = author
        self._patron = None
        self._waitingList = []

    def __str__(self):
        """Returns a string describing the book's properties."""
        
        result =  'Title: ' + self._title + '\n'
        result += 'Author: ' + self._author + '\n'
        result += 'Currently on loan to: '
        if self._patron == None:
            result += 'NA\n'
        else:
            result += self._patron.getName() + '\n'
        result += 'Waiting list:'
        if len(self._waitingList) == 0:
            result += '\n  None'
        else:
            for name in range(len(self._waitingList)):
                result += '\n  ' + self._waitingList[name].getName()
        return result


    def getTitle(self):
        """Returns the book's title."""
        
        return self._title


    def getAuthor(self):
        """Returns the book's author."""
        
        return self._author


    def getPatron(self):
        """Returns the patron object currently borrowing the book."""
        
        return self._patron


    def getWaitingList(self):
        """Returns the list of patrons waiting to check out the book."""
        
        return self._waitingList


    def removeFromWaitingList(patron):
        """Removes a patron from the book's waiting list."""
        
        if patron in self._waitingList:
            self._waitingList.remove(patron)
            print('\nBook:  Patron removed from waiting list')


    def loanBook(self, patron):
        """Loans the book to a patron.  If the book is already on loan
           or if the patron is currently borrowing the maximum allowed
           number of books, the patron is, instead, placed on the book's
           waiting list."""
        
        if (self._patron == None) and (patron.getNumberOfBooks() < MAXIMUM):
            self._patron = patron
            patron.borrowBook(self)
            if patron in self._waitingList:
                self._waitingList.remove(patron)
        elif patron not in self._waitingList:
            self._waitingList.append(patron)
            print('\nBook:  ' + patron.getName() +
                  ' added to the waiting list for ' + self._title)
        else:
            print('\nBook:  ' + patron.getName() +
                  ' already on waiting list for ' + self._title)


    def returnBook(self, patron):
        """Returns the book if it is currently on loan and automatically
           loans the book to the next eligible patron (if any) on the book's
           waiting list."""
        
        if self._patron != None:
            patron.returnBook(self)
            print('\nBook: ' + patron.getName() + ' returned ' + self._title)
            self._patron = None
            if len(self._waitingList) > 0:
                for newPatron in self._waitingList:
                    if newPatron.getNumberOfBooks() < MAXIMUM:
                        self._patron = newPatron
                        self._waitingList.remove(newPatron)
                        newPatron.borrowBook(self)
                        print('\nBook: ' + newPatron.getName() + ' borrowed '
                              + self._title + '; removed from waiting list.')
        else:
            print('\nBook: ' + patron.getName() + ' does not have ' +
                  self._title)


class Patron(object):
    """This class represents a library patron."""

    def __init__(self, name):
        """Initialize the Patron object."""
        
        self._name = name
        self._books = []


    def __str__(self):
        """Returns a string describing the patron's properties."""
        
        result =  'Patron Name: ' + self._name + '\n'
        result += 'Books currently on loan to this patron:'
        if len(self._books) == 0:
            result += '\n  None'
        else:
            for book in range(len(self._books)):
                result += '\n  ' + self._books[book].getTitle()
        return result


    def getName(self):
        """Returns the patron's name."""
        
        return self._name


    def getBooks(self):
        """Returns the list of books currently on loan to the patron as
           a list of book objects."""
        
        return self._books


    def getNumberOfBooks(self):
        """Returns the number of books currently on loan to the patron."""
        
        return len(self._books)


    def borrowBook(self, book):
        """Attempts to borrow a book."""
        
        if len(self._books) < MAXIMUM:
            self._books.append(book)
            print('\nPatron: ' + self._name + ' borrowed ' + book.getTitle())
        else:
            print('\nPatron: ' + self._name +
                  ' already has the maximum number of books on loan.')
            book.loanBook(self)


    def returnBook(self, book):
        """Return a book."""
        
        if book in self._books:
            self._books.remove(book)
            print('\nPatron: ' + self._name + ' returned ' + book.getTitle())
        else:
            print('\nPatron: ' + self._name + ' does not have ' +
                  book.getTitle())


class Library(object):
    """This class represents a library to handle patrons and books."""

    def __init__(self):
        """Initialize Library object."""
        
        self._bookList = []
        self._patronList = []


    def __str__(self):
        """Returns a string describing the library's properties."""
        
        result = 'Books:\n\n'
        for book in self._bookList:
            result += str(book) + '\n\n'
        result += '\n\nPatrons:\n\n'
        for patron in self._patronList:
            result += str(patron) + '\n\n'
        return result


    def loanBook(self, patron, book):
        """Loans a book to a patron."""

        book.loanBook(patron)


    def returnBook(self, patron, book):
        """Returns a book from a patron."""

        book.returnBook(patron)

    def addBook(self, book):
        """Adds a book to the library."""
        
        self._bookList.append(book)
        print('\nLibrary:  ' + book.getTitle() + ' by ' + book.getAuthor() +
              ' added to library.')


    def removeBook(self, book):
        """Removes a book from the library."""
        
        if book in self._bookList:
            self._bookList.remove(book)
            print('\nLibrary:  ' + book.getTitle() + ' removed from library.')
        else:
            print('\nLibrary:  ' + book.getTitle() + ' not in library.')


    def findBook(self, title):
        """Finds a book in the library."""
        
        for book in self._bookList:
            if book.getTitle() == title:
                print('\nBook found:\n')
                print(book)
                return book
        print('\n' + title + ' not found.')
        return None


    def getBookList(self):
        """Returns a list of all books in the library as a list of
           book objects."""
        
        return self._bookList


    def addPatron(self, patron):
        """Adds a patron to the library."""
        
        self._patronList.append(patron)


    def removePatron(self, patron):
        """Removes a patron from the library."""
        
        if patron.getNumberOfBooks() > 0:
            print('\nLibrary:  That patron has books on loan! ' +
                  'Please return or remove those books before removing ' +
                  'this patron.')
            return
        if patron in self._patronList:
            for book in self._bookList:
                if patron in book.getWaitingList():
                    book.removeFromWaitingList(patron)
            self._patronList.remove(patron)
            print('\nLibrary:  ' + patron.getName() + ' removed from library.')
        else:
            print('\nLibrary:  ' + patron.getName() + ' not a patron.')


    def findPatron(self, name):
        """Finds a patron in the library."""
        
        for patron in self._patronList:
            if patron.getName() == name:
                print('\nLibrary - Patron found:')
                print(patron)
                return patron
        print('\nLibrary:  Patron ' + name + ' not found.')
        return None

    def getPatronList(self):
        """Returns a list of patrons in the library as a list of
           patron objects."""
        
        return self._patronList


class LibraryManager(object):
    """This class provides a menu-driven command processor for managing
       the library class."""

    def __init__(self, library):
        """Initialize the Manager object."""
        self._library = library


    def __str__(self):
        """Returns a string describing the manager's properties."""
        return 'Library manager.'


    def getMenuChoice(self, first, last):
        """Select a menu option in the number range of first to last."""
        
        choice = last + 1
        while choice not in range(first, last + 1):
            try:
                choice = int(input('\nEnter menu choice (' + str(first) +
                                   ' - ' + str(last) +'): '))
            except ValueError:
                print('\nInvalid menu selection.')
                continue
            else:
                if choice not in range(first, last + 1):
                    print('\nInvalid menu selection.')
        return choice


    def managerMainMenu(self):
        """Displays the manager's main menu and returns the selection."""

        menuFirst = 1
        menuLast  = 5

        while True:
            print('\n\nLibrary Manager Main Menu:')
            print('1) Loan a book.')
            print('2) Return a book.')
            print('3) Edit books.')
            print('4) Edit patrons.')
            print('5) Exit Manager.')
            choice = self.getMenuChoice(menuFirst, menuLast)
            if choice == 1:
                self.managerLoanBook(self._library)
            elif choice == 2:
                self.managerReturnBook(self._library)
            elif choice == 3:
                self.managerEditBooksMenu(self._library)
            elif choice == 4:
                self.managerEditPatronsMenu(self._library)
            else:
                print('\n\nManager:  Goodbye!')
                return


    def managerEditBooksMenu(self, library):
        """Add, remove, or find a book or list all books in the library."""

        menuFirst = 1
        menuLast  = 5

        while True:
            print('\n\nEdit Books Menu:')
            print('1) Add a book to the library.')
            print('2) Remove a book from the library.')
            print('3) Find a book in the library.')
            print('4) List all books in the library.')
            print('5) Return to the main menu.')
            choice = self.getMenuChoice(menuFirst, menuLast)
            if choice == 1:
                self.managerAddBook(library)
            elif choice == 2:
                self.managerRemoveBook(library)
            elif choice == 3:
                self.managerFindBook(library)
            elif choice == 4:
                self.managerListBooks(library)
            else: return

       
    def managerEditPatronsMenu(self, library):
        """Add, remove, or find a patron or list all patrons of the library."""

        menuFirst = 1
        menuLast  = 5

        while True:
            print('\n\nEdit Patrons Menu:')
            print('1) Add a patron to the library.')
            print('2) Remove a patron from the library.')
            print('3) Find a patron of the library.')
            print('4) List all patrons of the library.')
            print('5) Return to the main menu.')
            choice = self.getMenuChoice(menuFirst, menuLast)
            if choice == 1:
                self.managerAddPatron(library)
            elif choice == 2:
                self.managerRemovePatron(library)
            elif choice == 3:
                self.managerFindPatron(library)
            elif choice == 4:
                self.managerListPatrons(library)
            else: return


    def managerLoanBook(self, library):
        """Loans a book."""

        patronNameList = []
        for patron in library.getPatronList():
            patronNameList.append(patron.getName())
        patronName = ''
        print('\nEnter the name of the patron (or ENTER to return to ' +
              'the previous menu)')
        while patronName not in patronNameList:
            patronName = input('\nPatron name: ')
            if patronName == '': return
            elif patronName not in patronNameList:
                print('\n' + patronName + ' not found.')
        patron = library.findPatron(patronName)

        bookTitleList = []
        for book in library.getBookList():
            bookTitleList.append(book.getTitle())
        bookTitle = ''
        print('\nEnter the title of the book (or ENTER to return to ' +
              'the previous menu): ')
        while bookTitle not in bookTitleList:
            bookTitle = input('\nBook name: ')
            if bookTitle == '': return
            elif bookTitle not in bookTitleList:
                print('\n' + bookTitle + ' not found.')
        book = library.findBook(bookTitle)

        if book not in patron.getBooks():
            library.loanBook(patron, book)
        else:
            print('\nPatron already has that book.')

    def managerReturnBook(self, library):
        """Returns a book."""
        
        patronNameList = []
        for patron in library.getPatronList():
            patronNameList.append(patron.getName())
        patronName = ''
        print('\nEnter the name of the patron (or just press ENTER to ' +
              'return to the previous menu):')
        while patronName not in patronNameList:
            patronName = input('\nPatron name: ')
            if patronName == '': return
            elif patronName not in patronNameList:
                print('\nManager: ' + patronName + ' not found.')
        patron = library.findPatron(patronName)
        if patron.getNumberOfBooks() == 0:
            print('\nPatron has no books on loan.')
            return

        book = None
        while book not in library.getBookList():
            bookTitle = input('\nEnter the title of the book to return (or ' +
                              'just press ENTER to return to\n the previous ' +
                              'menu): ')
            if bookTitle == '': return
            book = library.findBook(bookTitle)
            if book == None:
                print('\nManager: ' + bookTitle + ' not found.')
            elif book not in patron.getBooks():
                print('\nManager: Patron does not have that book.')
                book = None

        library.returnBook(patron, book)


    def managerAddBook(self, library):
        """Add a book to the library being managed."""
        
        title = ''
        print('\nEnter the title of the book to be added (or just press ' +
              'ENTER to return to the main menu).')
        title = input('  Title: ')
        if title == '': return
        print('\nEnter the author of the book (or just press ENTER ' +
              'to return to the main menu).')
        author = input('  Author: ')
        if author == '': return
        print("")
        library.addBook(Book(title, author))
        print('\nManager:  Book added!')


    def managerRemoveBook(self, library):
        """Remove a book from the library being managed."""
        
        bookList = library.getBookList()
        numberOfBooks = len(bookList)
        if numberOfBooks == 0:
            print('\nNo books in library!')
            return
        bookNumber = 1
        for book in bookList:
            print('\nBook number ' + str(bookNumber))
            print(str(book))
            bookNumber += 1

        choice = 0
        print('\nEnter the number of the book to be removed (or just ' +
              'press ENTER to return to the main menu).')
        while choice not in range (1, bookNumber + 1):
            choiceString = input('\nBook number: ')
            if choiceString == '': return
            try:
                choice = int(choiceString)
            except ValueError:
                print('\nInvalid book number.')
                continue
            else:
                if choice not in range(1, bookNumber + 1):
                    print('\nInvalid book number.')

        print('\nRemove this book:\n')
        print(bookList[choice - 1])
        enterYN = ''
        while enterYN == '':
            enterYN = input('\nY/N? ')
            enterYN = enterYN[0].upper()
            if enterYN not in ('Y', 'N'):
                print('\nInvalid selection.')
                enterYN = ''
        print("")
        if enterYN == 'Y':
            library.removeBook(bookList[choice - 1])
            print('\nManager: Book removed!')


    def managerFindBook(self, library):
        """Finds a book in the library being managed."""
        
        bookName = ''
        print('\nEnter the name of the book to find (or just press ' +
              'ENTER to return to the main menu).')
        bookName = input('  Book name: ')
        if bookName == '': return
        print("")
        library.findBook(bookName)


    def managerListBooks(self, library):
        """Lists the books in the library being managed."""
        
        bookList = library.getBookList()
        for book in bookList:
            print('\n' + str(book))


    def managerAddPatron(self, library):
        """Add a patron to the library being managed."""
        
        name = ''
        print('\nEnter the name of the patron to be added (or just press ' +
              'ENTER to return to the main menu).')
        name = input('\nName: ')
        if name == '': return
        library.addPatron(Patron(name))
        print('\nManager:  Patron added!')


    def managerRemovePatron(self, library):
        """Remove a patron from the library being managed."""
        
        patronList = library.getPatronList()
        numberOfPatrons = len(patronList)
        if numberOfPatrons == 0:
            print('\nLibrary has no patrons!')
            return
        patronNumber = 1
        print("")
        for patron in patronList:
            print('\nPatron number ' + str(patronNumber))
            print(str(patron))
            patronNumber += 1
        
        choice = 0
        print('\nEnter the number of the Patron to be removed (or just ' +
              'press ENTER to return to the main menu).')
        while choice not in range (1, patronNumber + 1):
            choiceString = input('\nPatron number: ')
            if choiceString == '': return
            try:
                choice = int(choiceString)
            except ValueError:
                print('\nInvalid patron number.')
                continue
            else:
                if choice not in range(1, patronNumber + 1):
                    print('\nInvalid patron number.')

        print('\nRemove this patron:\n')
        print(patronList[choice - 1])
        enterYN = ''
        while enterYN == '':
            enterYN = input('\nY/N? ')
            enterYN = enterYN[0].upper()
            if enterYN not in ('Y', 'N'):
                print('\nInvalid selection.')
                enterYN = ''
        print("")
        if enterYN == 'Y':
            library.removePatron(patronList[choice - 1])


    def managerFindPatron(self, library):
        """Find a patron of the library being managed."""
        
        patronName = ''
        print('\nEnter the name of the patron to find (or just press ' +
              'ENTER to return to the main menu).')
        patronName = input('  Patron name: ')
        if patronName == '': return
        library.findPatron(patronName)


    def managerListPatrons(self, library):
        """List the patrons of the library being managed."""
        
        patronList = library.getPatronList()
        for patron in patronList:
            print('\n' + str(patron))


def main():
    """Main function."""

    # create library
    library = Library()

    # create and add books to library
    library.addBook(Book('Harry Potter', 'J.K. Rowling'))
    library.addBook(Book('The Lord of the Rings', 'J.R.R. Tolkien'))
    library.addBook(Book('The Crystal Shard', 'R.A. Salvatore'))
    library.addBook(Book('Cavernss of Socrates', 'Dennis L. McKiernan'))
    library.addBook(Book('War and Peace', 'Leo Tolstoy'))
    library.addBook(Book('Beneath the Bleachers', 'Seymore Butts'))
    library.addBook(Book('A Mad Dash for the Outhouse', 'Willie Maykit'))
    library.addBook(Book('On the Yellow River', 'I.P. Freely'))
    library.addBook(Book('Will Trump be Impeached?', 'Betty Izz'))
    library.addBook(Book('Did Trump Collude?', 'Hugh Betcha'))

    # create and add patrons to library
    library.addPatron(Patron('Robin Blaine'))
    library.addPatron(Patron('Rocky Mazarow'))
    library.addPatron(Patron('Greg Davis'))
    library.addPatron(Patron('Stan Lee'))
    library.addPatron(Patron('Godzilla'))

    print("")
    print(library)
    print("")

    manager = LibraryManager(library)
    manager.managerMainMenu()

main()
