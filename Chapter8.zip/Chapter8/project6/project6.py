"""
Student:  Robin G. Blaine
Date:     November 2, 2017
Class:   _Python Programming

Assignment (Module 3, Chapter 8, Project 6):
Develop the Book and Patron classes.

A Book has:
  A title
  An author
  A patron to whom it has been checked out
  A list of patrons waiting for that book to be returned

A Patron has:
  A name
  A list of books that patron has checked out (maximum 3)

When a patron wants to borrow a book, that patron is automatically added
to that book's waiting list if the book has already been checked out. When
a patron returns a book, it is automatically loaned to the first patron on
its wait list who can check out a book (that is, they do not already have
3 books checked out).

Write a short script to test these classes.
"""

import random

MAXIMUM = 3

class Book(object):
    """This class represents a book."""

    def __init__(self, title, author):
        self._title = title
        self._author = author
        self._patron = None
        self._waitingList = []

    def __str__(self):
        result =  'Title: ' + self._title + '\n'
        result += 'Author: ' + self._author + '\n'
        result += 'Currently on loan to: '
        if self._patron == None:
            result += 'NA\n'
        else:
            result += self._patron.getName() + '\n'
        result += 'Waiting list:'
        if len(self._waitingList) == 0:
            result += '\n  None'
        else:
            for name in range(len(self._waitingList)):
                result += '\n  ' + self._waitingList[name].getName()
        return result

    def getTitle(self):
        return self._title

    def getAuthor(self):
        return self._author

    def getPatron(self):
        return self._patron

    def getWaitingList(self):
        return self._waitingList

    def loanBook(self, patron):
        if (self._patron == None) and (patron.getNumberOfBooks() < MAXIMUM):
            self._patron = patron
            patron.addBook(self)
            if patron in self._waitingList:
                self._waitingList.remove(patron)
        elif patron not in self._waitingList:
            self._waitingList.append(patron)
            print('Book:  ' + patron.getName() +
                  ' added to the waiting list for ' + self._title)
        else:
            print('Book:  ' + patron.getName() +
                  ' already on waiting list for ' + self._title)

    def returnBook(self, patron):
        if self._patron == patron:
            patron.removeBook(self)
            print('Book: ' + patron.getName() + ' returned ' + self._title)
            self._patron = None
            if len(self._waitingList) > 0:
                for newPatron in self._waitingList:
                    if newPatron.getNumberOfBooks() < MAXIMUM:
                        self._patron = newPatron
                        self._waitingList.remove(newPatron)
                        newPatron.addBook(self)
                        print('Book: ' + newPatron.getName() + ' borrowed '
                              + self._title + '; removed from waiting list.')
        else:
            print('Book: ' + patron.getName() + ' does not have ' +
                  self._title)

class Patron(object):
    """This class represents a library patron."""

    def __init__(self, name):
        self._name = name
        self._books = []

    def __str__(self):
        result =  'Patron Name: ' + self._name + '\n'
        result += 'Books currently on loan to this patron:'
        if len(self._books) == 0:
            result += '\n  None'
        else:
            for book in range(len(self._books)):
                result += '\n  ' + self._books[book].getTitle()
        return result

    def getName(self):
        return self._name

    def getBooks(self):
        return self._books

    def getNumberOfBooks(self):
        return len(self._books)

    def addBook(self, book):
        if len(self._books) < MAXIMUM:
            self._books.append(book)
            print('Patron: ' + self._name + ' borrowed ' + book.getTitle())
        else:
            print('Patron: ' + self._name +
                  ' already has the maximum number of books on loan.')

    def removeBook(self, book):
        if book in self._books:
            self._books.remove(book)
            print('Patron: ' + self._name + ' returned ' + book.getTitle())
        else:
            print('Patron: ' + self._name + ' does not have ' +
                  book.getTitle())

def listBooks(books):
    print('\nBooks:\n')
    for n in range(len(books)):
        print(books[n], '\n')

def listPatrons(patrons):
    print('\nPatrons:\n')
    for n in range(len(patrons)):
        print(patrons[n], '\n')

def libraryStatus(books, patrons):
    print('\nLibrary status:\n')
    listBooks(books)
    print("")
    listPatrons(patrons)
    print("")

def main():
    """Main function: This function tests the Book and Patron classes."""

    bookList = []
    bookList.append(Book('Harry Potter', 'J.K. Rowling'))
    bookList.append(Book('The Lord of the Rings', 'J.R.R. Tolkien'))
    bookList.append(Book('The Crystal Shard', 'R.A. Salvatore'))
    bookList.append(Book('Cavernss of Socrates', 'Dennis L. McKiernan'))
    bookList.append(Book('War and Peace', 'Leo Tolstoy'))
    bookList.append(Book('Beneath the Bleachers', 'Seymore Butts'))
    bookList.append(Book('A Mad Dash for the Outhouse', 'Willie Maykit'))
    bookList.append(Book('On the Yellow River', 'I.P. Freely'))
    bookList.append(Book('Will Trump be Impeached?', 'Betty Izz'))
    bookList.append(Book('Did Trump Collude?', 'Hugh Betcha'))
    lastBook = len(bookList) - 1

    patronList = []
    patronList.append(Patron('Robin Blaine'))
    patronList.append(Patron('Rocky Mazarow'))
    patronList.append(Patron('Greg Davis'))
    patronList.append(Patron('Stan Lee'))
    patronList.append(Patron('Godzilla'))
    lastPatron = len(patronList) - 1

    libraryStatus(bookList, patronList)
    pressEnterToContinue = input('\nPress ENTER to continue...')
    print("\n")

    # randomly loan books
    print("Randomly loaning books...\n")
    for x in range(20):
        b = random.randint(0, lastBook)
        p = random.randint(0, lastPatron)
        if bookList[b] not in patronList[p].getBooks():
            bookList[b].loanBook(patronList[p])
            print("")

    libraryStatus(bookList, patronList)
    pressEnterToContinue = input('\nPress ENTER to continue...')
    print("\n")

    # randomly return books
    print("Randomly returning books...\n")
    for x in range(10):
        p = random.randint(0, lastPatron)
        if patronList[p].getNumberOfBooks() > 0:
            book = random.choice(patronList[p].getBooks())
            book.returnBook(patronList[p])
            print("")

    libraryStatus(bookList, patronList)

main()
