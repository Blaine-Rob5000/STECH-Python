"""
Student:  Robin G. Blaine
Date:     November 2, 2017
Class:   _Python Programming

Assignment (Module 3, Chapter 8, Project 6):
Develop the Book and Patron classes.

A Book has:
  A title
  An author
  A patron to whom it has been checked out
  A list of patrons waiting for that book to be returned

A Patron has:
  A name
  A list of books that patron has checked out (maximum 3)

When a patron wants to borrow a book, that patron is automatically added
to that book's waiting list if the book has already been checked out. When
a patron returns a book, it is automatically loaned to the first patron on
its wait list who can check out a book (that is, they do not already have
3 books checked out).

Write a short script to test these classes.

Pseudocode:

"""
MAXIMUM = 3

class Book(object):
    """This class represents a book."""

    def __init__(self, title, author, patron, waitingList):
        self._title = title
        self._author = author
        self._patron = patron
        self._waitingList = waitingList

    def __str__(self):
        result =  'Title: ' + self._title + '\n'
        result += 'Author: ' + self._author + '\n'
        result += 'Currently on loan to: '
        if self._patron == '':
            result += 'NA\n'
        else:
            result += self._patron + '\n'
        result += 'Waiting list:'
        if len(self._waitingList) == 0:
            result += '\n  None'
        else:
            for n in range(len(self._waitingList)):
                result += '\n  ' + self._waitingList[n]
        return result

    def getTitle():
        return self._title

    def getAuthor():
        return self._author

    def getOnLoanTo():
        return self._patron

    def getWaitingList():
        return self._waitingList

    def loanBook(patron):
        if self._patron == None:
            self._patron = patron
            return True
        else:
            self._waitingList.append(patron)
            return False

    def returnBook():
        self._patron = None
        if len(self._waitingList) > 0:
            for name in self._waitingList:
                if Patron(name).getNumberOnLoan() < MAXIMUM:
                    self._patron = name
                    self._waitingList.remove(name)

class Patron(object):
    """This class represents a library patron."""

    def __init__(self, name, books):
        self._name = name
        self._books = books

    def __str__(self):
        result =  'Patron Name: ' + self._name + '\n'
        result += 'Books currently on loan to this patron:'
        if len(self._books) == 0:
            result += '\n  None'
        else:
            for n in range(len(self._books)):
                result += '\n  ' + self._books[n]
        return result

    def getName(self):
        return self._name

    def getBooksOnLoan(self):
        return self._books

    def getNumberOnLoan(self):
        return len(self._books)

    def loanBook(bookName):
        if len(self._books) < MAXIMUM:
            self._books.append(bookName)
            print(bookName + ' loaned to ' + self._name + '.')
            print(self)
        else:
            print(self._name + ' already has the maximum number of ' +
                  + 'books on loan.')
            print(self)

    def returnBook(bookName):
        if bookName in self._books:
            self._books.remove(bookName)
            print(bookName + ' returned by ' + self._name + '.')
            print(self)
        else:
            print(self._name + ' has not borrowed ' + bookName + '.')
            print(self)

def listBooks(books):
    print('\nBooks:\n')
    for n in range(len(books)):
        print(books[n], '\n')

def listPatrons(patrons):
    print('\nPatrons:\n')
    for n in range(len(patrons)):
        print(patrons[n], '\n')

def main():
    """Main function: This function tests the Book and Patron classes."""

    books = []
    books.append(Book('Harry Potter', 'J.K. Rowling', '', ''))
    books.append(Book('The Lord of the Rings', 'J.R.R. Tolkien', '', ''))
    books.append(Book('The Crystal Shard', 'R.A. Salvatore', '', ''))
    books.append(Book('Cavernss of Socrates', 'Dennis L. McKiernan', '', ''))
    books.append(Book('War and Peace', 'Leo Tolstoy', '', ''))

    patrons = []
    patrons.append(Patron('Robin Blaine', ''))
    patrons.append(Patron('Rocky Mazarow', ''))
    patrons.append(Patron('Greg Davis', ''))

    listBooks(books)
    print("")
    listPatrons(patrons)
    print("")
    cont = input('\nPress ENTER to continue...')

main()
