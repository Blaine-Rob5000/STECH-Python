"""
Student:  Robin G. Blaine
Date:     October 24, 2017
Class:   _Python Programming

Assignment (Module 2, Chapter 6, Project 10):
define and test a function: myRange

Pseudocode:
Define Function myRange(*arg)
  myList = []
  start = 0
  stop = 0
  step = 1
  If fewer than 1 or more than 3 arguments:
    Return None
  Else If 1 argument:
    end = arg[0]
  Else If 2 arguments:
    start = arg[0]
    stop = arg[1]
  Else If 3 arguments:
    start = arg[0]
    stop = arg[1]
    step = arg[2]
  While start <= stop:
    Append start to myList
    start = start + step
  Return myList
"""

def myRange(*arg):
    # variables
    numArgs = len(arg)
    myList = []
    start = 0
    stop = 0
    step = 1
    # determine start, stop, and step based on arguments submitted
    if (numArgs < 1) or (numArgs > 3):
        return None
    elif numArgs == 1:
        stop = arg[0]
    elif numArgs == 2:
        start = arg[0]
        stop = arg[1]
    elif numArgs == 3:
        start = arg[0]
        stop = arg[1]
        step = arg[2]
        if start > stop:
            step = -abs(step) # if start > stop, step must be negative
    # append items to myList
    if start <= stop:
        while start <= stop:
            myList.append(start)
            start += step
    else:
        while start >= stop:
            myList.append(start)
            start += step
    # return myList
    return myList

def main():
    print("Testing myRange([start,] stop [, step]) function:\n\n")
    print("          myRange():", myRange())
    print("")
    print("         myRange(5):", myRange(5))
    print("")
    print("     myRange(3, 11):", myRange(3, 11))
    print("")
    print("  myRange(7, 62, 4):", myRange(7, 62, 4))
    print("")
    print(" myRange(10, 0, -1):", myRange(10, 0, -1))
    print("")
    print(" myRange(27, 15, 2):", myRange(27, 15, 2))
    print("    (treat step as a negative number if start > stop)\n")
    print("myRange(1, 2, 3, 4):", myRange(1, 2, 3, 4))
    print("")

main()
