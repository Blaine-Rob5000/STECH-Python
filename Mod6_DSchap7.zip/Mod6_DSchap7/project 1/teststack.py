"""
File: teststack.py
Author: Ken Lambert
A tester program for stack implementations.

Modified by:  Robin G. Blaine on December 11, 2017


Student:  Robin G. Blaine
Date:     December 11, 2017
Class:   _Python Programming

Assignment (Module 6, Data Structures - Chapter 7, Project 1):
    Complete and test the linked and array implementations of the stack collection
    type discussed in this chapter. Verify that exceptions are raised when
    preconditions are violated and that the array-based implementation adds or
    removes storage as needed.
"""


from arraystack import ArrayStack
from linkedstack import LinkedStack

def test(stackType):
    # Test any implementation with same code
    s = stackType()
    print("  Length:", len(s))
    if stackType == ArrayStack:
        print("  Physical Size:", len(s._items))
    print("  Empty:", s.isEmpty())
    print("  Push 1-10")
    for i in range(10):
        s.push(i + 1)
    print("  Peeking:", s.peek())
    print("  Items (bottom to top):",  s)
    print("  Length:", len(s))
    if stackType == ArrayStack:
        print("  Physical Size:", len(s._items))
    print("  Empty:", s.isEmpty())
    theClone = stackType(s)
    print("  Items in clone (bottom to top):",  theClone)
    theClone.clear()
    print("  Length of clone after clear:",  len(theClone))
    if stackType == ArrayStack:
        print("  Physical Size:", len(s._items))
    print("  Push 11")
    s.push(11)
    print("  Length:", len(s))
    if stackType == ArrayStack:
        print("  Physical Size:", len(s._items))
    print("  Popping items (top to bottom): ", end="")
    while not s.isEmpty(): print(s.pop(), end=" ")
    print("\n  Length:", len(s))
    if stackType == ArrayStack:
        print("  Physical Size:", len(s._items))
    print("  Empty:", s.isEmpty())
    try:
        s.pop()
    except KeyError:
        print("  Key Error: Cannot Pop. Stack is empty...")


print("Testing ArrayStack:")
test(ArrayStack)
print("\n\nTesting LinkedStack:")
test(LinkedStack)
