"""
Student:  Robin G. Blaine
Date:     December 11, 2017
Class:   _Python Programming

Assignment (Module 6, Data Structures - Chapter 7, Project 2):
    Write a program that uses a stack to test input strings to determine whether they
    are palindromes. A palindrome is a sequence of words that reads the same as the
    sequence in reverse.
"""


from arraystack import ArrayStack

def main():
    print("                 * * * PALINDROME TESTER * * *\n")
    print("Test whether or not a word or series of words is a palindrome.")
    print("           Only characters and digits are counted.")
    print("    Spaces, punctuation, and capitalization are ignored.")
    print("Enter a blank string to quit. (Just press ENTER at the prompt.)")
    forwardStack = ArrayStack()
    forwardClone = ArrayStack()
    reverseStack = ArrayStack()
    while True:
        palindrome = input("\n\nEnter string: ")
        if not palindrome:
            break
        palindrome = palindrome.lower()
        for char in palindrome:
            if char.isalnum():
                forwardStack.push(char)
                forwardClone.push(char)
        while not forwardClone.isEmpty():
            reverseStack.push(forwardClone.pop())
        if forwardStack == reverseStack:
            print("\nThat's a palindrome!")
        else:
            print("\nSorry, that's not a palindrome...")
        forwardStack.clear()
        forwardClone.clear()
        reverseStack.clear()
        
    print("\n\nGoodbye!")

main()