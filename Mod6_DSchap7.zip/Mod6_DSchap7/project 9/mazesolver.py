"""
Student:  Robin G. Blaine
Date:     December 11, 2017
Class:   _Python Programming

Assignment (Module 6, Data Structures - Chapter 7, Project 9):
	Write a program that solves the maze problem discussed earlier in this chapter.
	You should use the Grid class developed in Chapter 4 in this problem. The
	program should input a description of the maze from a text file at start-up. The
	program then displays this maze, attempts to find a solution, displays the result,
	and displays the maze once more.
"""

