"""
Student:  Robin G. Blaine
Date:     October 26, 2017
Class:   _Python Programming

Assignment (Module 2, Chapter 7, Project 9): pg 290
Develop 3 algorithms (lighten, darken, colorFilter) for lightening,
darkening, and color filtering an image. (Note that colorFilter should do
most of the work.)

Pseudocode:

"""

