"""
Student:  Robin G. Blaine
Date:     October 26, 2017
Class:   _Python Programming

Assignment (Module 2, Chapter 7, Project 10): pg 291
The edge-detection function described in this chapter returns a black-and-
white image. Think of a similar way to transform color values so that the
new image is still in its original colors but the outlines within it are
merely sharpened.  Then, define a function named sharpen that performs this
operation.  The function should expect an image and two integers as arguments.
One integer should represent the degree to which the image should be sharpened.
The other integer should represent the threshold used to detect edges. (Hint:
A pixel can be darkened by making its RGB values smaller.)

Pseudocode:
Define Function sharpen(image, degree, threshold):

  Define Function average(rgb):
    (r, g, b) = rgb
    return (r + g + b) // 3

  Define Function darken(rgb, d):
    (r, g, b) = rgb
    r -= d
    If r < 0: r = 0
    g -= d
    If g < 0: g = 0
    b -= d
    If b < 0: b = 0
    return (r, g, b)

  new = image.clone()

  For y in Range(0 To image.height - 1):
    For x in Range(1 To image.width):
      oldPixel = image.getPixel(x, y)
      leftPixel = image.getPixel(x - 1, y)
      bottomPixel = image.getPixel(x, y + 1)
      oldLum = average(oldPixel)
      leftLum = average(leftPixel)
      bottomLum = average(bottomPixel)
      If abs(oldLum - leftLum) > threshold or \
         abs(oldLum - bottomLum) > threshold:
           new.setPixel(x, y, darken(oldPixel, degree))
  Return new

Define Function main():
  Input degreeToSharpen
  Input detectionThreshold
  
  Load originalImage
  Display originalImage

  newImage = sharpen(originalImage, degreeToSharpen, detectionThreshold)
  Display newImage

main()    
"""

from images import Image

def sharpen(image, degree, threshold):

    def average(rgb):
        (r, g, b) = rgb
        return (r + g + b) // 3

    def darken(rgb, d):
        (r, g, b) = rgb
        r -= d
        if r < 0: r = 0
        g -= d
        if g < 0: g = 0
        b -= d
        if b < 0: b = 0
        return (r, g, b)

    new = image.clone()
    
    for y in range(image.getHeight() - 1):
        for x in range(1, image.getWidth()):
            oldPixel = image.getPixel(x, y)
            leftPixel = image.getPixel(x - 1, y)
            bottomPixel = image.getPixel(x, y + 1)
            oldLum = average(oldPixel)
            leftLum = average(leftPixel)
            bottomLum = average(bottomPixel)
            if abs(oldLum - leftLum) > threshold or \
               abs(oldLum - bottomLum) > threshold:
                new.setPixel(x, y, darken(oldPixel, degree))
    return new

def main():
    print("Enter the degree by which to sharpen edges...")
    degreeToSharpen = int(input("(0 to 255):"))
    print("\nEnter the threshold for detecting edges...")
    detectionThreshold = int(input("(10 to 30):"))

    originalImage = Image("gif1.gif")

    print("\nImage before processing... Close image to see results.")
    originalImage.draw()
    print("\nImage after sharpening edges...")
    newImage = sharpen(originalImage, degreeToSharpen, detectionThreshold)
    newImage.draw()

main()
