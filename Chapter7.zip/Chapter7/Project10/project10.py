"""
Student:  Robin G. Blaine
Date:     October 26, 2017
Class:   _Python Programming

Assignment (Module 2, Chapter 7, Project 10): pg 291
Design a single function (transform) which expects an image and another
function as arguments.  When called, it should be passed to another function
that expects a tuple of integers and returns a tuple of integers. This is
the function that transforms the information for a an individual pixel
(such as converting it to black and white or grayscale). The transform
function contains the loop logic for traversing its image argument. In the
body of the loop, the transform function access the pixel at the current
position, passes it as an argument to the other function, and resets the pixel
in the image to the function's value.

Write and test a script that defines this function and uses it to perform
at least two types of transformations on an image.

Pseudocode:

"""

