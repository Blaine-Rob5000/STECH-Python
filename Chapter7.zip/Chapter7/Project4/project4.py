"""
Student:  Robin G. Blaine
Date:     October 26, 2017
Class:   _Python Programming

Assignment (Module 2, Chapter 7, Project 4): pgs 288-289
Design, implement, and test a script that uses a recursive function to draw
patterns in the style of twentieth century Dutch artist Piet Mondrian.
Fill a rectangle with a random color, then repeatedly fill two unequal
subdivisions with random colors. (Use one-third and two-thirds of the
base rectangle's area and alternate division between vertical and horizontal
axes.)

Pseudocode:

"""

