"""
Student:  Robin G. Blaine
Date:     October 26, 2017
Class:   _Python Programming

Assignment (Module 2, Chapter 7, Project 4): pgs 288-289
Design, implement, and test a script that uses a recursive function to draw
patterns in the style of twentieth century Dutch artist Piet Mondrian.
Fill a rectangle with a random color, then repeatedly fill two unequal
subdivisions with random colors. (Use one-third and two-thirds of the
base rectangle's area and alternate division between vertical and horizontal
axes.)

Pseudocode:
Define Function fillRectangle(turtle, h, w)
  Random r, g, & b (0 to 255)
  t.fillcolor(r, g, b)
  t.begin_fill()
  For side In (w, h, w, h):
    t.forward(side)
    t.right(90)
  t.end_fill()

Define Function drawMondrian(t, h, w, r)
  fillRectangle(t, h, w, r)
  If r == 0:
    Return
  Else:
    If r is even:
      drawMondrian(t, h, w // 3, r - 1)
      drawMondrian(t, h // 3, w, r - 1)
    Else:
      drawMondrian(t, h // 3, w, r - 1)
      drawMondrian(t, h, w // 3, r - 1)

Define Function main():
  Input recursion level (1 to 4)

  turtle = Turtle()
  set up Turtle
  set up height and width based on screen size

  drawMondrian(turtle, height, width, recursion)

main()
"""

from turtle import Turtle
import random

def fillRectangle(t, h, w):
    whitespace = random.choice([True, False, False])
    if whitespace:
        r = 255
        g = 255
        b = 255
    else:
        r = random.randint(0, 255)
        g = random.randint(0, 255)
        b = random.randint(0, 255)

    t.fillcolor(r, g, b)

    t.begin_fill()
    for side in (w, h, w, h):
        t.forward(side)
        t.right(90)
    t.end_fill()

def drawMondrian(t, h, w, r):
    fillRectangle(t, h, w)
    if r == 0:
        return
    else:
        if r % 2 == 0:
            drawMondrian(t, h, w // 3, r - 1)
            drawMondrian(t, h // 3, w, r - 1)
        else:
            drawMondrian(t, h // 3, w, r - 1)
            drawMondrian(t, h, w // 3, r - 1)

def main():
    recursion = 0
    while recursion not in range(1, 5):
        recursion = int(input("Enter recursion level (1 to 4): "))
    
    turtle = Turtle()

    turtle.screen.colormode(255)
    turtle.pencolor(0, 0, 0)
    turtle.width(3)
    turtle.speed('fast')

    width = turtle.screen.window_width() // 2
    height = turtle.screen.window_height() // 2

    x = int(width * .9)
    width = x * 2
    y = int(height * .9)
    height = y * 2

    turtle.up()
    turtle.goto(-x, y)
    turtle.setheading(0)
    turtle.down()

    drawMondrian(turtle, height, width, recursion)

main()
