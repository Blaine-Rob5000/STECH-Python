"""
Student:  Robin G. Blaine
Date:     October 26, 2017
Class:   _Python Programming

Assignment (Module 2, Chapter 7, Project 3): pg 288
Write a script that draws the Koch snowflake.

Pseudocode:

"""

