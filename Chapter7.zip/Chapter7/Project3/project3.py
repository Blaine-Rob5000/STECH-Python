"""
Student:  Robin G. Blaine
Date:     October 26, 2017
Class:   _Python Programming

Assignment (Module 2, Chapter 7, Project 3): pg 288
Write a script that draws the Koch snowflake.

Pseudocode:
Define Function drawFractalLine(t, distance, level):
  If level > 0:
    For angle In [60, -120, 60, 0]:
      drawFractralLine(t, distance // 3, level - 1)
      t.left(angle)
    Else:
      t.forward(distance)

Define Function drawKoch(t, distance, level):
  For side In range(3):
    drawFractalLine(t, distance, level)
    t.right(120)

Define Function main():
  Input("Enter level:") level

  set startX, startY, and distance based on screen size

  drawKoch(t, distance, level)
"""
from turtle import Turtle

def drawFractalLine(t, distance, level):
    """?"""
    if level > 0:
        for angle in [60, -120, 60, 0]:
            drawFractalLine(t, distance // 3, level - 1)
            t.left(angle)
    else:
        t.forward(distance)

def drawKoch(t, distance, level):
    for side in range(3):
        drawFractalLine(t, distance, level)
        t.right(120)

def main():
    level = int(input("Enter level: "))

    t = Turtle()

    screenW = t.screen.window_width() // 2
    screenH = t.screen.window_height() // 2
    screen = min(screenW, screenH)

    startX = 0
    startY = -(screenW // 2)
    t.up()
    t.goto(startX, startY)
    t.setheading(120)
    t.down()
    t.speed('fast')
    
    distance = int((1.25 * screen ** 2) ** .5)

    drawKoch(t, distance, level)

main()
