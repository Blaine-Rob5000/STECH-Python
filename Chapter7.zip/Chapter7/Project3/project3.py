"""
Student:  Robin G. Blaine
Date:     October 24, 2017
Class:   _Python Programming

Assignment (Module 2, Chapter 7, Project 3):

Pseudocode:

"""

