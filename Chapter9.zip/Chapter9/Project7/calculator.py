"""
Student:  Robin G. Blaine
Date:     November 13, 2017
Class:   _Python Programming

Assignment (Module 3, Chapter 9, Project 7):
Write a GUI-based program that simulates a simple pocket calculator.
The GUI displays a single entry field for output.  The GUI should also
display a keypad of buttons for the 10 digits and 6 command buttons
labeled +, -, *, /, C, and =. The command C should clear the output
field. The command = calculates an anwer and siplays it in the field.
The program should build a string from the user's button clicks and echo
it in the field.  The program should detect any errors during this process
and display the word "ERR" in the field.
"""

from tkinter import *

class Calculator(Frame):
    """This class creates a GUI for a simple pocket calculator."""

    def __init__(self):
        """Initializes the variables and widgets."""

        Frame.__init__(self)
        self.master.title("Calculator")
        self.grid(padx = 10, pady = 10)

        # error flag
        self._error = False

        # output string and label
        self._outputStr = ""
        self._outputLabel = Label(self, text = self._outputStr,
                                  width = 30, relief = SUNKEN, anchor = E)
        self._outputLabel.grid(row = 0, column = 0, columnspan = 4)

        # 0 button
        self._numberButton = []
        self._numberButton.append(Button(self, text = "0",
                                         command = lambda: self._pressNum(0),
                                         width = 3))
        self._numberButton[0].grid(row = 4, column = 1)

        # buttons for numbers 1 to 9
        for digit in range(1, 10):
            self._numberButton.append(Button(self, text = str(digit),
                                             command = lambda n = digit: self._pressNum(n),
                                             width = 3))
            r = 3 - (digit - 1) // 3
            c = (digit - 1) % 3
            self._numberButton[digit].grid(row = r, column = c)

        # C button
        self._clearButton = Button(self, text = "C",
                                   command = lambda: self._clear(),
                                   width = 3)
        self._clearButton.grid(row = 4, column = 0)

        # = button
        self._equalsButton = Button(self, text = "=",
                                    command = lambda: self._equals(),
                                    width = 3)
        self._equalsButton.grid(row = 4, column = 2)

        # + button
        self._addButton = Button(self, text = "+",
                                 command = lambda: self._add(),
                                 width = 3)
        self._addButton.grid(row = 4, column = 3)

        # - button
        self._subtractButton = Button(self, text = "-",
                                      command = lambda: self._subtract(),
                                      width = 3)
        self._subtractButton.grid(row = 3, column = 3)

        # * button
        self._multiplyButton = Button(self, text = "*",
                                      command = lambda: self._multiply(),
                                      width = 3)
        self._multiplyButton.grid(row = 2, column = 3)

        # / button
        self._divideButton = Button(self, text = "/",
                                    command = lambda: self._divide(),
                                    width = 3)
        self._divideButton.grid(row = 1, column = 3)


    def _updateOutput(self):
        """Updates the output label."""

        self._outputLabel.configure(text = self._outputStr)


    def _pressNum(self, num):
        """The user press one of the number buttons.
    num: integer ranging from 0 to 9"""

        if not self._error:
            if self._outputStr == "0":
                self._outputStr = str(num)
            else:
                self._outputStr += str(num)
            self._updateOutput()


    def _clear(self):
        """Clears the output string."""

        self._error = False
        self._outputStr = ""
        self._updateOutput()


    def _equals(self):
        """Performs the calculations in the output string and displays the result."""

        if not self._error:
            # if nothing to be done, clear output
            if self._outputStr == "" or self._outputStr == "-":
                self._outputStr = ""
                self._updateOutput()
                return

            # if last character in output string is not a digit, ERR
            if not self._outputStr[-1].isdigit():
                self._outputStr = "ERR"
                self._error = True
                self._updateOutput()
                return

            # split the output string into a list of numbers and operators
            result = 0
            tempStr = ""
            numbers = []
            operations = []
            if self._outputStr[0] == "-":
                tempStr = "-"
                self._outputStr = self._outputStr[1:]
            for char in self._outputStr:
                if char.isdigit():
                    tempStr += char
                else:
                    numbers.append(int(tempStr))
                    tempStr = ""
                    if char == "-":
                        tempStr += "-"
                        operations.append("+")
                    else:
                        operations.append(char)
            numbers.append(int(tempStr))
            
            # parse numbers and operations lists into a result
            number = 0
            while "*" in operations or "/" in operations:
                for operator in operations:
                    if operator != "+":
                        index = operations.index(operator)
                        operations.pop(index)
                        number = numbers.pop(index)
                        if operator == "*":
                            numbers[index] *= number
                        else:
                            if numbers[index] == 0:
                                self._error = True
                                self._outputStr = "ERR"
                                self._updateOutput()
                                return
                            else:
                                numbers[index] = number / numbers[index]
            for n in numbers:
                result += n
            self._outputStr = str(result)
            self._updateOutput()


    def _add(self):
        """Adds a + sign to the output string."""

        if not self._error:
            if self._outputStr == "-":
                self._outputStr = ""
            elif self._outputStr != "":
                if self._outputStr[-1].isdigit():
                    self._outputStr += "+"
                else:
                    self._outputStr = self._outputStr[:-1] + "+"
            self._updateOutput()


    def _subtract(self):
        """Adds a - sign to the output string."""

        if not self._error:
            if self._outputStr == "":
                self._outputStr = "-"
                self._updateOutput()
                return
            if self._outputStr[-1].isdigit():
                self._outputStr += "-"
            else:
                self._outputStr = self._outputStr[:-1] + "-"
            self._updateOutput()


    def _multiply(self):
        """Adds a * sign to the output string."""

        if not self._error:
            if self._outputStr == "-":
                self._outputStr = ""
            elif self._outputStr != "":
                if self._outputStr[-1].isdigit():
                    self._outputStr += "*"
                else:
                    self._outputStr = self._outputStr[:-1] + "*"
            self._updateOutput()


    def _divide(self):
        """Adds a / sign to the output string."""

        if not self._error:
            if self._outputStr == "-":
                self._outputStr = ""
            elif self._outputStr != "":
                if self._outputStr[-1].isdigit():
                    self._outputStr += "/"
                else:
                    self._outputStr = self._outputStr[:-1] + "/"
            self._updateOutput()


def main():
    """The main function."""

    calculator = Calculator()
    calculator.mainloop()


main()
