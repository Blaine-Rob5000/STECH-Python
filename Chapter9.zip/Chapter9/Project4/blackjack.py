"""
Student:  Robin G. Blaine
Date:     November 8, 2017
Class:   _Python Programming

Assignment (Module 3, Chapter 9, Project 4):
  Write a GUI program that plays blackjack with the user.
  <Card and Deck classes are taken from student data files.>


Blackjack rules:

Player and dealer receive 2 cards each.
  The player's cards are both face up. The dealer has 1 card face up
  and 1 card face down (the 'hole card').

Card values:
  1) Aces are worth 11 or 1 (whichever is more favorable).
      (A hand with an Ace valued at 11 is called a 'soft' hand, as it will
       not bust by taking an additional card; otherwise the hand is 'hard.')
  2) Number cards (2 - 10) are worth their number value.
  3) Face cards are worth 10.

The player can take additional cards ('hit') until they decide to stop
  ('stand') or their card total goes over 21 ('bust').

If the player busts, the dealer wins.

Once the player has a card total of 21 or stands, the dealer plays:
  1) The dealer reveals the hole card.
  2) The dealer hits on 16 or lower or on a soft 17, otherwise he stands.
  3) If the dealer busts, the player wins.

Winning:
  1) Whoever has the higher hand at the end wins.
  2) A tie is called a 'push.'
"""

from tkinter import *
from cards import Card, Deck

class Blackjack (Frame):

    def __init__(self):
        """Sets up the window and widgets"""
        Frame.__init__(self)
        
        self.master.title("Blackjack, v1.0 - by RGBlaine")
        self.grid()
        self._deck = Deck()
        self._backImage = PhotoImage(file = Card.BACK_NAME)
        self._cardImage = None

        self._dealerLabel = Label(self, text = "Dealer")
        selr._dealerLabel.grid(row = 0, column = 0) # ???

        self._dealerHandLabel = Label(self, text = "Hand:")
        self._dealerHandLabel.grid(row = 0, column = 2) # ???

        self._statusLabel = Label(self, text = "")
        self._statusLabel.grid(row = 2, column = 2) # ???

        self._playerLabel = Label(self, text = "Player")
        self._playerLabel.grid(row = 4, column = 0) # ???

        self._playerHandLabel = Label(self, text = "Hand:")
        self._playerHandLabel.grid(row = 4, column = 2) # ???

        self._hitButton(self, text = "Hit", command = self._hit)
        self._hitButton.grid(row = 4, column = 7) # ???

        self._standButton(self, text = "Stand", command = self._stand)
        self._standButton.grid(row = 4, column = 8) # ???

        self._dealButton(self, text = "Deal", command = self._deal)
        self._dealButton.grid(row = 4, column = 9) # ???
