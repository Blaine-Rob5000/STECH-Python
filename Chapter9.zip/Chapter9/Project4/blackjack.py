"""
Student:  Robin G. Blaine
Date:     November 8, 2017
Class:   _Python Programming

Assignment (Module 3, Chapter 9, Project 4):
  Write a GUI program that plays blackjack with the user.

  Card and Deck classes are taken from student data files.
  Player and Dealer classes are taken from the textbook, Fundamentals of
  Python, First Programs.
"""

from tkinter import *
from cards import Card, Deck

class Blackjack(Frame):
    """This class allows the user to play Blackjack using a GUI."""
    
    def __init__(self):
        """Initialize the variables and widgets."""
        
        Frame.__init__(self)
        self.master.title("Blackjack")
        self.grid(ipadx = 5, ipady = 5, padx = 5, pady = 5)

        # initialize deck, player, and dealer
        self._deck = Deck()
        self._deck.shuffle()
        self._player = Player([self._deck.deal(), self._deck.deal()])
        self._dealer = Dealer([self._deck.deal(), self._deck.deal()])

        # card back and blank card
        self._backImage = PhotoImage(file = Card.BACK_NAME)
        self._blankCard = PhotoImage(file = "DECK/blank.gif")

        # dealer label
        self._dealerLabel = Label(self, text = "Dealer",
                                  font = ('Helvetica', '20'), height = 2)
        self._dealerLabel.grid(row = 0, column = 0, columnspan = 2)

        # labels for dealer's and player's cards
        self._dealerCardImage = []
        self._playerCardImage = []
        for x in range(10):
            self._dealerCardImage.append(Label(self, image = self._blankCard, height = 120))
            self._dealerCardImage[x].grid(row = 1, column = x)
            self._playerCardImage.append(Label(self, image = self._blankCard, height = 120))
            self._playerCardImage[x].grid(row = 3, column = x)

        # status label
        self._statusLabel = Label(self, text = "Click NEW GAME to begin.",
                                  font = ('Helvetica', '20'), width = 60, height = 2, relief = SUNKEN)
        self._statusLabel.grid(row = 2, column = 0, columnspan = 10)

        # player label
        self._playerLabel = Label(self, text = "Player",
                                  font = ('Helvetica', '20'), height = 2)
        self._playerLabel.grid(row = 4, column = 0, columnspan = 2)

        # widgets for buttons (hit, stand, new game)
        self._hitButton = Button(self, text = "Hit", command = self._hit, width = 8)
        self._hitButton.grid(row = 4, column = 7)

        self._standButton = Button(self, text = "Stand", command = self._stand, width = 8)
        self._standButton.grid(row = 4, column = 8)

        self._newGameButton = Button(self, text = "New Game", command = self._newGame, width = 8)
        self._newGameButton.grid(row = 4, column = 9)

        # flag to signify whether or not it is currently the player's turn
        self._playersTurn = False


    def _hit(self):
        """The player hits."""
        
        if self._playersTurn:
            card = self._deck.deal()
            self._player.hit(card)
            n = len(self._player.getCards()) - 1
            self._playerCardImage[n].configure(image = card.image)
            if self._player.getPoints() == 21:
                self._stand()
            elif self._player.getPoints() > 21:
                self._playersTurn = False
                self._statusLabel.configure(text = "You bust and lose.   Click NEW GAME to play again.")


    def _stand(self):
        """The player stands."""
        
        if self._playersTurn:
            self._playersTurn = False
            self._dealer.hit(self._deck)
            dealerCards = self._dealer.getCards()
            n = 0
            for card in dealerCards:
                self._dealerCardImage[n].configure(image = card.image)
                n += 1
            dealerPoints = self._dealer.getPoints()
            playerPoints = self._player.getPoints()
            if dealerPoints > 21:
                self._statusLabel.configure(text = "Dealer busts. You win.   Click NEW GAME to play again.")
            elif dealerPoints < playerPoints:
                self._statusLabel.configure(text = "You win.   Click NEW GAME to play again.")
            elif dealerPoints > playerPoints:
                self._statusLabel.configure(text = "Dealer wins.   Click NEW GAME to play again.")
            elif dealerPoints == playerPoints:
                if self._player.hasBlackjack() and not self._dealer.hasBlackjack():
                    self._statusLabel.configure(text = "You win.   Click NEW GAME to play again.")
                elif not self._player.hasBlackjack() and self._dealer.hasBlackjack():
                    self._statusLabel.configure(text = "Dealer wins. Click NEW GAME to play again.")
                else:
                    self._statusLabel.configure(text = "There is a tie.   Click NEW GAME to play again.")


    def _newGame(self):
        """Starts a new game."""
        
        # initialize new game
        self._playersTurn = True
        self._statusLabel.configure(text = "Hit or Stand")
        self._deck = Deck()
        self._deck.shuffle()
        self._player = Player([self._deck.deal(), self._deck.deal()])
        self._dealer = Dealer([self._deck.deal(), self._deck.deal()])
        # clear card images
        for n in range(10):
            self._playerCardImage[n].configure(image = self._blankCard)
            self._dealerCardImage[n].configure(image = self._blankCard)
        # display player's cards
        n = 0
        for card in self._player.getCards():
            self._playerCardImage[n].configure(image = card.image)
            n += 1
        # display dealer's face-up card and back of hole card
        dealerCards = self._dealer.getCards()
        card = dealerCards[0]
        self._dealerCardImage[0].configure(image = card.image)
        self._dealerCardImage[1].configure(image = self._backImage)
        # if player has blackjack then stand
        if self._player.hasBlackjack():
            self._stand()



class Player(object):
    """This class represents a player in a game of blackjack."""
    
    def __init__(self, cards):
        self._cards = cards

    def __str__(self):
        result = ", ".join(map(str, self._cards))
        result += "\n " + str(self.getPoints()) + " points"
        return result

    def hit(self, card):
        self._cards.append(card)

    def getPoints(self):
        count = 0
        for card in self._cards:
            if card.rank > 9:
                count += 10
            elif card.rank == 1:
                count += 11
            else:
                count += card.rank
        for card in self._cards:
            if count <= 21:
                break
            elif card.rank == 1:
                count -= 10
        return count

    def getCards(self):
        return self._cards

    def hasBlackjack(self):
        return len(self._cards) == 2 and self.getPoints() == 21


class Dealer(Player):
    """This class represents the dealer in a game of blackjack."""

    def __init__(self, cards):
        Player.__init__(self, cards)
        self._showOneCard = True

    def __str__(self):
        if self._showOneCard:
            return str(self._cards[0])
        else:
            return Player.__str__(self)

    def hit(self, deck):
        self._showOneCard = False
        while self.getPoints() < 17:
            self._cards.append(deck.deal())



def main():
    game = Blackjack()
    game.mainloop()

main()
