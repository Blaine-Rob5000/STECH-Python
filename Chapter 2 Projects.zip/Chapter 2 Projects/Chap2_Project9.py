"""
Student:  Robin G. Blaine
Date:     October 17, 2017
Class:   _Python Programming

Assignment (Module 1, Chapter 2, Project 9):
Write a program that takes as input a number of kilometers and prints the
corresponding number of nautical miles.  Use the following:
* A kilometer represents 1/10,000 of the distance between the North Pole
  and the equator.
* There are 90 degrees, containing 60 minutes of arc each, between the
  North Pole and the equator.
* A nautical mile is 1 minute of an arc.

Pseudocode:
Input kilometers ("Enter the number of kilometers: ")
nauticalMiles = kilometers * .54
Output nauticalMiles (kilometers, "km =", nauticalMiles, "nautical miles")
"""

kilometers = float(input("Enter the number of kilometers: "))
nauticalMiles = kilometers * .54
print(kilometers, "km =", nauticalMiles, "nautical miles")
