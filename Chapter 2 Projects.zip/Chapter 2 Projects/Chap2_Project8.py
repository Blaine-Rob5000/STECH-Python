"""
Student:  Robin G. Blaine
Date:     October 17, 2017
Class:   _Python Programming

Assignment (Module 1, Chapter 2, Project 8):
Light travels at 3 * 10^8 meters per second. A light-year is the distance a
light beam travels in one year. Write a program that calculates and
displays the value of a light-year.

Pseudocode:
lightSpeed = 3 * 10 ** 8
secondsPerYear = 365 * 24 * 60 * 60
lightYear = lightSpeed * secondsPerYear
Output lightYear ("A light year is", lightYear, "meters")
"""

lightSpeed = 3 * 10 ** 8 # light speed in meters per second
secondsPerYear = 365 * 24 * 60 * 60  # days * hours * minutes * seconds
lightYear = lightSpeed * secondsPerYear
print("A light year is", lightYear, "meters")

