"""
Student:  Robin G. Blaine
Date:     October 17, 2017
Class:   _Python Programming

Assignment (Module 1, Chapter 2, Project 7):
Write a program that calculates and prints the number of minutes in a year.

Pseudocode:
minutesPerStandardYear = 365 * 24 * 60
minutesPerLeapYear = 366 * 24 * 60
minutesPerAverageYear = 365.25 * 24 * 60
"""

minutesPerStandardYear = 365 * 24 * 60
minutesPerLeapYear = 366 * 24 * 60
minutesPerAverageYear = 365.25 * 24 * 60
print("The number of minutes per standard year: ", minutesPerStandardYear)
print("The number of minutes per leap year: ", minutesPerLeapYear)
print("The number of minutes per 'average' year:", minutesPerAverageYear)
