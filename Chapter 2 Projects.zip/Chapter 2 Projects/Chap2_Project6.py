"""
Student:  Robin G. Blaine
Date:     October 17, 2017
Class:   _Python Programming

Assignment (Module 1, Chapter 2, Project 6):
The kinetic energy of a moving object is given by the formula
KE = (1/2)mv^2, where m is the object's mass and v is its velocity.
Modify the program you created in Project 5 so that it prints the
object's kinetic energy as well as its momentum.

Pseudocode:
Input mass ("Enter the object's mass in kilograms: ")
Input velocity ("Enter the objects velocity in meters per second: ")
momentum = mass * velocity
kineticEnergy = .5 * mass * velocity^2
Output mass ("The object's momentum is", mass, "kg m/s")
Output kineticEnergy ("The object's kinetic energy is", kineticEnergy, "kg m^2/s^2")
"""

mass = float(input("Enter the object's mass in kilograms: "))
velocity = float(input("Enter the object's velocity in meters per second: "))
momentum = mass * velocity
kineticEnergy = .5 * mass * velocity ** 2
print("The object's momentum is", momentum, "kg m/s")
print("The object's kinetic energy is", kineticEnergy, "kg m^2/s^2")
