"""
Student:  Robin G. Blaine
Date:     October 17, 2017
Class:   _Python Programming

Assignment (Module 1, Chapter 2, Project 5):
An object's momentum is its mass multiplied times its velocity.
Write a program that accepts an object's mass (in kilograms) and
velocity (in meters per second) as inputs and then outputs its
momentum.

Pseudocode:
Input mass ("Enter the object's mass in kilograms: ")
Input velocity ("Enter the objects velocity in meters per second: ")
momentum = mass * velocity
Output mass ("The object's momentum is", mass, "kg m/s")
"""

mass = float(input("Enter the object's mass in kilograms: "))
velocity = float(input("Enter the object's velocity in meters per second: "))
momentum = mass * velocity
print("The object's momentum is", momentum, "kg m/s")
