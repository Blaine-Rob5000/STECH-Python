"""
Student:  Robin G. Blaine
Date:     November 30, 2017
Class:   _Python Programming

Assignment (Module 5, Data Structures - Chapter 5, Project 3):
	A sorted bag behaves just like a regular bag but allows the user to visit its items in
	ascending order with the for loop. Therefore, the items added to this type of bag
	must have a natural ordering and recognize the comparison operators. Some
	examples of such items are strings and integers.
	
	Define a new class named ArraySortedBag that supports this capability. Like
	ArrayBag, this new class is array based, but its in operation can now run in
	logarithmic time. To accomplish this, ArraySortedBag must place new items into its
	array in sorted order. The most efficient way to do this is to modify the add method
	to insert new items in their proper places. You also have to include a __contains__
	method to implement the new, more efficient search. Finally, you must change all
	references to ArrayBag to be ArraySortedBag. (Another hint: copy the code from the
	ArrayBag class to the new file and begin making your changes from there.)
	
"""

from arraySortedBag import ArraySortedBag

def main():
	"""?"""
	

main()
