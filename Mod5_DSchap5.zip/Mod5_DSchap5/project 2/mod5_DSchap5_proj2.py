"""
Student:  Robin G. Blaine
Date:     November 30, 2017
Class:   _Python Programming

Assignment (Module 5, Data Structures - Chapter 5, Project 2):
	Complete the code for the ArrayBag methods add and remove, so that the array is
	resized when necessary.
"""

from arraybag import ArrayBag

def main():
	"""Tests the changes made to the ArrayBag class."""
	
	bag1 = ArrayBag([1, 2, 3, 4])
	print("\nbag1:", bag1)
	print("Logical size:", len(bag1))
	print("Physical size:", len(bag1._items))
	for item in bag1:
		print(item)
	
	bag2 = ArrayBag([5, 6, 7, 8, 9, 10])
	print("\nbag2:", bag2)
	print("Logical size:", len(bag2))
	print("Physical size:", len(bag2._items))
	for item in bag2:
		print(item)
	
	print("\nbag1 = bag2:", bag1 == bag2)
	
	bag3 = bag1 + bag2
	print("\nbag3:", bag3)
	print("Logical size:", len(bag3))
	print("Physical size:", len(bag3._items))
	for item in bag3:
		print(item)
	
	print("\nbag3 = bag1:", bag3 == bag1)
	print("bag3 = bag2:", bag3 == bag1)
	print("bag3 = bag1 + bag2:", bag3 == bag1 + bag2)
	
	bag1.clear()
	print("\nbag1:", bag1)
	
	bag2.clear()
	print("\nbag2:", bag2)
	
	for count in range(5):
		bag3.add(count + 11)
	print("\nbag3:", bag3)
	print("Logical size:", len(bag3))
	print("Physical size:", len(bag3._items))
	
	for count in range(2, 15, 2):
		bag3.remove(count)
	print("\nbag3:", bag3)
	print("Logical size:", len(bag3))
	print("Physical size:", len(bag3._items))
	
	for count in range(1, 15, 4):
		bag3.remove(count)
	print("\nbag3:", bag3)
	print("Logical size:", len(bag3))
	print("Physical size:", len(bag3._items))


main()
