Student:  Robin G. Blaine
Date:     December 1, 2017
Class:   _Python Programming

Assignment (Module 6, Data Structures - Chapter 6, Project 4):
	A set behaves just like a bag, except that a set cannot contain duplicate items.
	Some possible implementations are ArraySet and LinkedSet. Draw a class diagram
	that shows where you would place these new classes in the collection framework
	shown in figure 6.3


