"""
Student:  Robin G. Blaine
Date:     December 1, 2017
Class:   _Python Programming

Assignment (Module 6, Data Structures - Chapter 6, Project 10):
	The remove method in the LinkedBag class has the redundant search described in
	Project 8. Modify this class so that this redundancy no longer exists.
"""

from linkedbag import LinkedBag

def main():
	"""Tests the changes made to the LinkedBag class."""
	
	bag1 = LinkedBag([1, 2, 3, 4])
	print("\nbag1:", bag1)
	print("Logical size:", len(bag1))
	for item in bag1:
		print(" ", item)
	
	bag2 = LinkedBag([5, 6, 7, 8, 9, 10])
	print("\nbag2:", bag2)
	print("Logical size:", len(bag2))
	for item in bag2:
		print(" ", item)
	
	print("\nbag1 = bag2:", bag1 == bag2)
	
	bag3 = bag1 + bag2
	print("\nbag3:", bag3)
	print("Logical size:", len(bag3))
	for item in bag3:
		print(" ", item)
	
	print("\nbag3 = bag1:", bag3 == bag1)
	print("bag3 = bag2:", bag3 == bag1)
	print("bag3 = bag1 + bag2:", bag3 == bag1 + bag2)
	
	bag1.clear()
	print("\nbag1:", bag1)
	
	bag2.clear()
	print("\nbag2:", bag2)
	
	for count in range(5):
		bag3.add(count + 11)
	print("\nbag3:", bag3)
	print("Logical size:", len(bag3))
	
	for count in range(2, 15, 2):
		bag3.remove(count)
		print(count, "removed...")
		print(bag3)
	print("\nbag3:", bag3)
	print("Logical size:", len(bag3))
	
	for count in range(1, 14, 4):
		bag3.remove(count)
		print(count, "removed...")
	print("\nbag3:", bag3)
	print("Logical size:", len(bag3))


main()
