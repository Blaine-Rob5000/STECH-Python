"""
Student:  Robin G. Blaine
Date:     December 1, 2017
Class:   _Python Programming

Assignment (Module 6, Data Structures - Chapter 6, Project 10):
	The remove method in the LinkedBag class has the redundant search described in
	Project 8. Modify this class so that this redundancy no longer exists.
"""

