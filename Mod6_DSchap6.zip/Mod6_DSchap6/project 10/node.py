"""
File: node.py
Author: Ken Lambert

Modified by: Robin G. Blaine
"""

class Node(object):
	"""Represents a doubly-linked node."""
	
	def __init__(self, data, previous = None, next = None):
		"""Instantiates a Node with a default next of None."""
		self.data = data
		self.previous = previous
		self.next = next
	
	def __str__(self):
		"""Returns a string representation of self."""
		return "\n  Data: " + str(self.data) + "\n  Previous: " + str(self.previous) + "\n  Next: " + str(self.next)
	