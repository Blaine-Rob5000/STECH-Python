"""
File: linkedbag.py
Author: Robin G. Blaine
"""

from node import Node

class LinkedBag(object):
	"""An node-based bag implementation."""
	
	#Constructor
	def __init__(self, sourceCollection = None):
		"""Sets the initial state of self which includes the
		contents of sourceCollection, if it's present."""
		self._head = Node(None)
		self._tail = self._head
		self._size = 0
		self._targetNode = None
		if sourceCollection:
			for item in sourceCollection:
				self.add(item)
	
	#Accessor methods
	def isEmpty(self):
		"""Returns True if len(self) == 0,
		or False otherwise."""
		return len(self) == 0
	
	def __len__(self):
		"""Returns the number of items in self."""
		return self._size
	
	def __str__(self):
		"""Returns the string representation of self."""
		return "{" + ", ".join(map(str, self)) + "}"
	
	def __iter__(self):
		"""Supports iteration over a view of self."""
		probe = self._head.next
		while probe != None:
			yield probe.data
			probe = probe.next
	
	def __contains__(self, targetItem):
		"""Returns True if the target item is in the bag, False otherwise."""
		probe = self._head.next
		while probe != None:
			if probe.data == targetItem:
				self._targetNode = probe
				return True
			probe = probe.next
		self._targetNode = None
		return False
	
	def __add__(self, other):
		"""Returns a new bag containing the contents of self and other."""
		result = LinkedBag(self)
		for item in other:
			result.add(item)
		return result
		
	def __eq__(self, other):
		"""Returns True if self equals other,
		or False otherwise."""
		if self is other: return True
		if type(self) != type(other) or len(self) != len(other):
			return False
		for item in self:
			if not item in other:
				return False
		return True
			
	#Mutator methods
	def clear(self):
		"""Makes self become empty."""
		self._size = 0
		probe = self._head
		while probe != None:
			nextNode = probe.next
			probe.data = None
			probe.previous = None
			probe.next = None
			probe = nextNode
		self._head = Node(None)
		self._tail = self._head
	
	def add(self, item):
		"""Adds item to self."""
		#Add item and increment logical size
		newNode = Node(item)
		if len(self) == 0:
			self._head.next = newNode
		else:
			lastNode = self._tail.previous
			lastNode.next = newNode
			newNode.previous = lastNode
		self._tail.previous = newNode
		self._size += 1
	
	def remove(self, item):
		"""Precondition: item in self.
		Raises: KeyError if item is not in self.
		Postcondition: item is removed from self."""
		#Check precondition and raise if necessary
		if not item in self:
			raise KeyError(str(item) + " not in bag")
		#Otherwise, change node pointers and clear the item
		previousNode = self._targetNode.previous
		nextNode = self._targetNode.next
				
		if previousNode == None:
			self._head.next = nextNode
		else:
			previousNode.next = nextNode
		if nextNode == None:
			self._tail.previous = previousNode
		else:
			nextNode.previous = previousNode
			
		self._targetNode.data = None
		self._targetNode.next = None
		self._targetNode.previous = None
		self._targetNode = None
		#Decrement logical size
		self._size -= 1
