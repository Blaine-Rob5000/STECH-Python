"""
Student:  Robin G. Blaine
Date:     December 1, 2017
Class:   _Python Programming

Assignment (Module 6, Data Structures - Chapter 6, Project 8):
	Someone notices that the remove ooperation performs two searches of a bag: one
	during the test of the method's precondition (using the in operator) and the other
	to locate the position of the target item to actually remove it. One way to eliminate
	the redundant search is to track the position of the target item in an instance
	variable. In the case of an array-based bag, this positon would be -1 at the startup and
	whenever a target item is not found. If the in operator finds a target item, the
	position variable is set to that item's index in the array; otherwise, it is reset to -1.
	After the remove method checks its precondition, no search loop is necessary; the
	method can just close the hole in the array using the position variable. Modify the
	ArrayBag class to support this capability. Note that you will now to add a
	__contains__ method to ArrayBag that performs the customized search.
"""

